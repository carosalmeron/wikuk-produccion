import { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

// ── TOKENS ─────────────────────────────────────────────────────────────────────
const C = {
  bg:"#f4f4f4", card:"#ffffff", card2:"#f4f4f4",
  accent:"#e06000", text:"#1a1a1a", muted:"#888888",
  border:"#e0e0e0", green:"#1e7e3e", red:"#c0392b",
  blue:"#1a1a1a", purple:"#1a1a1a", yellow:"#b45309",
  greenBg:"#edf7f1", redBg:"#fdf0ef", blueBg:"#f4f4f4",
};
const F = { h:"'Barlow Condensed', sans-serif", b:"'Barlow', sans-serif" };

// ── STORAGE ────────────────────────────────────────────────────────────────────
// Capas: 1) Supabase (nube, multi-dispositivo)  2) localStorage  3) memoria
const DB = {};
const KEYS = ["cp_products","cp_orders","cp_registers","cp_users"];

const LS = {
  get(k){ try{ const v=localStorage.getItem(k); return v?JSON.parse(v):null; }catch{ return null; } },
  set(k,v){ try{ localStorage.setItem(k,JSON.stringify(v)); return true; }catch{ return false; } },
};

// Supabase client (sin librería, usando REST API directo)
const SB = {
  getConfig(){ 
    // Credenciales hardcodeadas — no requiere configuración
    return {url:"https://ujatjwkmjtxzhzkckqlu.supabase.co",key:"sb_publishable_LGRyEZf74XKtTaHljnDbYw_dljv2m0s"};
  },
  saveConfig(url,key){ 
    // no-op, credenciales fijas
  },
  clearConfig(){ 
    // no-op
  },
  async test(url,key){
    try{
      const r=await fetch(`${url.trim().replace(/\/$/,"")}/rest/v1/app_data?select=key&limit=1`,{
        headers:{"apikey":key.trim(),"Authorization":`Bearer ${key.trim()}`}
      });
      return r.ok||r.status===200;
    }catch{ return false; }
  },
  async get(k){
    const cfg=this.getConfig();
    if(!cfg)return null;
    try{
      const r=await fetch(`${cfg.url}/rest/v1/app_data?key=eq.${k}&select=value`,{
        headers:{"apikey":cfg.key,"Authorization":`Bearer ${cfg.key}`,"Content-Type":"application/json"}
      });
      if(!r.ok)return null;
      const rows=await r.json();
      return rows?.[0]?.value??null;
    }catch{ return null; }
  },
  async set(k,v){
    const cfg=this.getConfig();
    if(!cfg)return false;
    try{
      const r=await fetch(`${cfg.url}/rest/v1/app_data`,{
        method:"POST",
        headers:{"apikey":cfg.key,"Authorization":`Bearer ${cfg.key}`,"Content-Type":"application/json","Prefer":"resolution=merge-duplicates"},
        body:JSON.stringify({key:k,value:v,updated_at:new Date().toISOString()})
      });
      return r.ok||r.status===201||r.status===200;
    }catch{ return false; }
  },
};

const store = {
  async get(k){
    // 1. Supabase
    const sbv=await SB.get(k);
    if(sbv!=null){ DB[k]=sbv; LS.set(k,sbv); return sbv; }
    // 2. localStorage
    const lv=LS.get(k);
    if(lv!=null){ DB[k]=lv; return lv; }
    // 3. memoria
    return DB[k]??null;
  },
  async set(k,v){
    DB[k]=v;
    LS.set(k,v); // siempre guarda local
    const ok=await SB.set(k,v);
    return ok;
  },
  isCloud(){ return !!SB.getConfig(); },
  exportAll(){
    const data={};
    KEYS.forEach(k=>{ if(DB[k]!=null) data[k]=DB[k]; });
    return btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  },
  importAll(code){
    try{
      const data=JSON.parse(decodeURIComponent(escape(atob(code.trim()))));
      KEYS.forEach(k=>{ if(data[k]!=null){ DB[k]=data[k]; LS.set(k,data[k]); } });
      return data;
    }catch{ return null; }
  },
};

// ── UTILS ──────────────────────────────────────────────────────────────────────
const uid   = ()=>Math.random().toString(36).slice(2,9);
const today = ()=>new Date().toISOString().slice(0,10);
const fmtD  = d=>{const[y,m,day]=d.split("-");return`${day}/${m}/${y.slice(2)}`;};
const addDays=(d,n)=>{const x=new Date(d);x.setDate(x.getDate()+n);return x.toISOString().slice(0,10);};
const weekStart=()=>{const d=new Date();d.setDate(d.getDate()-d.getDay()+1);return d.toISOString().slice(0,10);};
const monthStart=()=>new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10);

// ── RESPONSIVE ────────────────────────────────────────────────────────────────
const useBreakpoint = () => {
  const ref = typeof document !== "undefined" ? document.getElementById("app-root") : null;
  const getW = () => {
    if(typeof window === "undefined") return 390;
    // Use the root element width to detect actual available space
    const el = document.getElementById("app-root");
    return el ? el.clientWidth : window.innerWidth;
  };
  const [w, setW] = useState(getW);
  useEffect(() => {
    const fn = () => setW(getW());
    window.addEventListener("resize", fn);
    // Also observe element resize
    const el = document.getElementById("app-root");
    let ro;
    if(el && window.ResizeObserver){
      ro = new ResizeObserver(()=>setW(getW()));
      ro.observe(el);
    }
    fn();
    return () => { window.removeEventListener("resize", fn); ro && ro.disconnect(); };
  }, []);
  return { isMobile: w < 600, isTablet: w >= 600 && w < 900, isDesktop: w >= 900, w };
};

// ── BASE UI ────────────────────────────────────────────────────────────────────
const Header=({title,onBack,sub})=>(
  <div style={{display:"flex",alignItems:"center",padding:"14px 16px 12px",background:C.card,borderBottom:`2px solid ${C.border}`,gap:12,position:"sticky",top:0,zIndex:10,boxShadow:"0 2px 8px rgba(0,0,0,0.08)"}}>
    {onBack&&<button onClick={onBack} style={{background:C.bg,border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:10,padding:"10px 16px",fontFamily:F.h,fontSize:22,fontWeight:800,cursor:"pointer",flexShrink:0,lineHeight:1}}>‹</button>}
    <div><h1 style={{fontFamily:F.h,fontWeight:800,fontSize:24,color:C.text,letterSpacing:0.5,margin:0}}>{title}</h1>{sub&&<div style={{fontSize:13,color:C.muted,marginTop:1}}>{sub}</div>}</div>
  </div>
);

const Card=({children,style={},color,onClick})=>(
  <div onClick={onClick} style={{background:C.card,border:`1.5px solid ${color||C.border}`,borderRadius:16,padding:18,cursor:onClick?"pointer":"default",boxShadow:"0 1px 4px rgba(0,0,0,0.06)",...style}}>{children}</div>
);

const Btn=({children,onClick,v="primary",disabled=false,style={}})=>{
  const base={
    fontFamily:F.h,fontWeight:700,fontSize:18,letterSpacing:0.3,
    borderRadius:12,padding:"16px 20px",cursor:disabled?"not-allowed":"pointer",
    width:"100%",display:"block",textAlign:"center",opacity:disabled?0.35:1,
    transition:"opacity 0.15s",
  };
  const vs={
    primary: {background:C.accent,  color:"#fff",       border:"none"},
    secondary:{background:"#fff",   color:C.text,       border:`1.5px solid ${C.border}`},
    ghost:   {background:"#fff",    color:C.accent,     border:`1.5px solid ${C.accent}`},
    danger:  {background:"#fff",    color:C.red,        border:`1.5px solid ${C.red}`},
    green:   {background:"#fff",    color:C.green,      border:`1.5px solid ${C.green}`},
    blue:    {background:"#fff",    color:C.text,       border:`1.5px solid ${C.border}`},
  };
  return <button onClick={disabled?undefined:onClick} style={{...base,...vs[v],...style}}>{children}</button>;
};

const Field=({label,value,onChange,type="text",placeholder="",min,step})=>(
  <div style={{marginBottom:16}}>
    {label&&<label style={{display:"block",fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,marginBottom:6,letterSpacing:0.5,textTransform:"uppercase"}}>{label}</label>}
    <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} min={min} step={step}
      style={{width:"100%",background:"#fff",border:`1.5px solid ${C.border}`,color:C.text,borderRadius:12,padding:"15px 16px",fontFamily:F.b,fontSize:18,outline:"none",boxSizing:"border-box",boxShadow:"inset 0 1px 3px rgba(0,0,0,0.05)"}}/>
  </div>
);

const Sel=({label,value,onChange,options=[],placeholder})=>(
  <div style={{marginBottom:16}}>
    {label&&<label style={{display:"block",fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,marginBottom:6,letterSpacing:0.5,textTransform:"uppercase"}}>{label}</label>}
    <select value={value} onChange={e=>onChange(e.target.value)}
      style={{width:"100%",background:"#fff",border:`1.5px solid ${C.border}`,color:value?C.text:C.muted,borderRadius:12,padding:"15px 16px",fontFamily:F.b,fontSize:18,outline:"none",appearance:"none",boxSizing:"border-box",boxShadow:"inset 0 1px 3px rgba(0,0,0,0.05)"}}>
      {placeholder&&<option value="">{placeholder}</option>}
      {options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

const Toast=({msg,ok=true})=>(
  <div style={{background:ok?C.greenBg:C.redBg,border:`1.5px solid ${ok?C.green:C.red}`,borderRadius:12,padding:"14px 16px",marginBottom:14,display:"flex",alignItems:"center",gap:10}}>
    <span style={{fontSize:20}}>{ok?"✓":"!"}</span>
    <span style={{fontFamily:F.b,fontWeight:600,fontSize:15,color:ok?C.green:C.red}}>{msg}</span>
  </div>
);

const StatusPill=({status})=>{
  const cfg={
    open:   {bg:C.greenBg, border:C.green, color:C.green, label:"● ABIERTA"},
    closed: {bg:"#f4f4f4", border:C.muted, color:C.muted, label:"✓ CERRADA"},
    planned:{bg:"#f4f4f4", border:C.muted, color:C.muted, label:"◷ PLANIFICADA"},
  };
  const s=cfg[status]||cfg.open;
  return <span style={{background:s.bg,border:`1.5px solid ${s.border}`,color:s.color,borderRadius:20,padding:"4px 12px",fontSize:13,fontFamily:F.h,fontWeight:700,letterSpacing:0.5}}>{s.label}</span>;
};



// ── LOGO ───────────────────────────────────────────────────────────────────────
const WikukBrand = ({size="large", dark=true}) => {
  const isLarge = size === "large";
  const fs      = isLarge ? 58 : 34;
  const w       = isLarge ? 200 : 118;
  const h       = isLarge ? 64  : 38;
  const color   = dark ? "#111827" : "#f1f5f9";
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} xmlns="http://www.w3.org/2000/svg">
      <text x="2" y={h * 0.82}
        fontFamily="'Arial Black','Helvetica Neue',Arial,sans-serif"
        fontWeight="900" fontSize={fs} letterSpacing="-1.5" fill={color}>wikuk</text>
      <text x={isLarge ? 183 : 108} y={isLarge ? 12 : 7}
        fontFamily="Arial" fontSize={isLarge ? 13 : 8} fill={color} opacity="0.5">®</text>
    </svg>
  );
};


// ── CLOUD SETUP SCREEN ─────────────────────────────────────────────────────────
function CloudSetupScreen({onDone}){
  const [step,setStep]=useState(1);
  const [url,setUrl]=useState("");
  const [key,setKey]=useState("");
  const [testing,setTesting]=useState(false);
  const [err,setErr]=useState("");
  const [ok,setOk]=useState(false);

  const test=async()=>{
    if(!url||!key){setErr("Completa los dos campos");return;}
    setTesting(true);setErr("");
    // Create table if needed
    try{
      const r=await fetch(`${url.trim().replace(/\/$/,"")}/rest/v1/app_data`,{
        method:"POST",
        headers:{"apikey":key.trim(),"Authorization":`Bearer ${key.trim()}`,"Content-Type":"application/json","Prefer":"resolution=merge-duplicates"},
        body:JSON.stringify({key:"_test",value:"ok",updated_at:new Date().toISOString()})
      });
      if(r.ok||r.status===201||r.status===200){
        SB.saveConfig(url,key);
        setOk(true);
        setTimeout(()=>onDone(),1500);
      } else {
        const body=await r.text();
        if(body.includes("app_data")||r.status===404){
          setErr("La tabla 'app_data' no existe. Sigue el paso 2 para crearla.");
        } else {
          setErr(`Error ${r.status}. Revisa que la URL y la clave sean correctas.`);
        }
      }
    }catch(e){setErr("No se pudo conectar. Revisa la URL.");}
    setTesting(false);
  };

  const skip=()=>{ SB.clearConfig(); onDone(); };

  const steps=[
    {
      title:"Crear cuenta gratuita",
      content:(
        <div>
          <p style={{color:C.muted,fontSize:15,lineHeight:1.6,marginBottom:16}}>
            Supabase es una base de datos gratuita en la nube. Tus datos se sincronizan entre todos los dispositivos automáticamente.
          </p>
          <div style={{background:C.card2,borderRadius:12,padding:16,marginBottom:16}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginBottom:12}}>Pasos:</div>
            {[
              "Ve a supabase.com",
              'Pulsa "Start your project"',
              "Regístrate con Google (más fácil)",
              'Pulsa "New project"',
              'Nombre: wikuk-produccion',
              'Región: West EU (Ireland)',
              "Espera ~2 minutos",
            ].map((s,i)=>(
              <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
                <span style={{background:C.accent,color:"#fff",borderRadius:"50%",width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:F.h,fontWeight:700,fontSize:13,flexShrink:0}}>{i+1}</span>
                <span style={{fontSize:14,color:C.text,lineHeight:1.5}}>{s}</span>
              </div>
            ))}
          </div>
          <Btn onClick={()=>setStep(2)}>Hecho, siguiente →</Btn>
        </div>
      )
    },
    {
      title:"Crear la tabla de datos",
      content:(
        <div>
          <p style={{color:C.muted,fontSize:15,lineHeight:1.6,marginBottom:16}}>
            Dentro de tu proyecto Supabase, crea la tabla donde se guardarán los datos.
          </p>
          <div style={{background:C.card2,borderRadius:12,padding:16,marginBottom:16}}>
            {[
              'En el menú izquierdo pulsa "SQL Editor"',
              'Pulsa "New query"',
              "Copia y pega este código:",
            ].map((s,i)=>(
              <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
                <span style={{background:C.accent,color:"#fff",borderRadius:"50%",width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:F.h,fontWeight:700,fontSize:13,flexShrink:0}}>{i+1}</span>
                <span style={{fontSize:14,color:C.text,lineHeight:1.5}}>{s}</span>
              </div>
            ))}
            <div style={{background:"#1a1a2e",borderRadius:8,padding:12,marginTop:8,marginBottom:12}}>
              <code style={{fontFamily:"monospace",fontSize:12,color:"#a5f3fc",lineHeight:1.7,display:"block"}}>
                {"create table app_data (\n  key text primary key,\n  value jsonb,\n  updated_at timestamptz\n);\nalter table app_data enable row level security;\ncreate policy \"public\" on app_data for all using (true) with check (true);"}
              </code>
            </div>
            <div style={{display:"flex",gap:10,marginBottom:4,alignItems:"flex-start"}}>
              <span style={{background:C.accent,color:"#fff",borderRadius:"50%",width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:F.h,fontWeight:700,fontSize:13,flexShrink:0}}>4</span>
              <span style={{fontSize:14,color:C.text}}>Pulsa "Run" (▶)</span>
            </div>
          </div>
          <Btn onClick={()=>setStep(3)}>Hecho, siguiente →</Btn>
        </div>
      )
    },
    {
      title:"Conectar con la app",
      content:(
        <div>
          <p style={{color:C.muted,fontSize:15,lineHeight:1.6,marginBottom:16}}>
            Ahora copia las credenciales de tu proyecto.
          </p>
          <div style={{background:C.card2,borderRadius:12,padding:16,marginBottom:16}}>
            {[
              'En Supabase ve a "Project Settings" (rueda dentada)',
              'Pulsa "API"',
              'Copia "Project URL" y "anon public key"',
            ].map((s,i)=>(
              <div key={i} style={{display:"flex",gap:10,marginBottom:8,alignItems:"flex-start"}}>
                <span style={{background:C.accent,color:"#fff",borderRadius:"50%",width:22,height:22,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:F.h,fontWeight:700,fontSize:13,flexShrink:0}}>{i+1}</span>
                <span style={{fontSize:14,color:C.text,lineHeight:1.5}}>{s}</span>
              </div>
            ))}
          </div>
          {err&&<div style={{background:C.redBg,border:`1.5px solid ${C.red}`,borderRadius:10,padding:12,marginBottom:14,fontSize:13,color:C.red,fontFamily:F.h,fontWeight:600}}>⚠️ {err}</div>}
          {ok&&<div style={{background:C.greenBg,border:`1.5px solid ${C.green}`,borderRadius:10,padding:12,marginBottom:14,fontSize:14,color:C.green,fontFamily:F.h,fontWeight:700}}>✅ ¡Conectado! Sincronizando datos…</div>}
          <Field label="Project URL" value={url} onChange={setUrl} placeholder="https://xxxxxxxxxxxx.supabase.co"/>
          <Field label="Anon Public Key" value={key} onChange={setKey} placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."/>
          <Btn onClick={test} disabled={testing||!url||!key} style={{marginBottom:10}}>
            {testing?"Conectando…":"✅ Conectar y guardar en la nube"}
          </Btn>
        </div>
      )
    }
  ];

  return(
    <div style={{minHeight:"100vh",background:"#f4f4f4",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{width:"100%",maxWidth:480}}>
        <div style={{textAlign:"center",marginBottom:24}}>
          <WikukBrand dark={true} size="large"/>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.text,marginTop:12}}>Configuración de sincronización en la nube</div>
          <div style={{fontSize:13,color:C.muted,marginTop:4}}>Paso {step} de 3</div>
        </div>
        {/* Progress bar */}
        <div style={{height:4,background:C.border,borderRadius:4,marginBottom:24,overflow:"hidden"}}>
          <div style={{height:"100%",width:`${(step/3)*100}%`,background:C.accent,borderRadius:4,transition:"width 0.3s"}}/>
        </div>
        <Card style={{marginBottom:14}}>
          <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text,marginBottom:16}}>{steps[step-1].title}</div>
          {steps[step-1].content}
        </Card>
        <button onClick={skip} style={{width:"100%",padding:"12px",border:"none",background:"transparent",color:C.muted,fontFamily:F.b,fontSize:14,cursor:"pointer",textDecoration:"underline"}}>
          Omitir — usar solo en este dispositivo
        </button>
      </div>
    </div>
  );
}

// ── LOGIN ──────────────────────────────────────────────────────────────────────
function LoginScreen({users,onLogin}){
  const [usr,setUsr]=useState("");
  const [pwd,setPwd]=useState("");
  const [err,setErr]=useState("");
  const login=()=>{
    const u=users.find(x=>x.username.toLowerCase()===usr.trim().toLowerCase()&&x.password===pwd);
    if(!u){setErr("Usuario o contraseña incorrectos");return;}
    setErr(""); onLogin(u);
  };
  return(
    <div style={{minHeight:"100vh",background:"#f0f2f5",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24}}>
      <div style={{width:"100%",maxWidth:560,margin:"0 auto"}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{display:"flex",justifyContent:"center",marginBottom:16}}>
            <WikukBrand dark={true} size="large"/>
          </div>
          <p style={{color:C.muted,fontSize:16,margin:0,fontFamily:F.b}}>Control de Producción — Identifícate</p>
        </div>
        <Card>
          {err&&<div style={{background:"#fff5f5",border:"1px solid #7f1d1d",borderRadius:10,padding:"12px 14px",marginBottom:14,color:C.red,fontFamily:F.h,fontSize:15}}>⚠️ {err}</div>}
          <Field label="Usuario" value={usr} onChange={setUsr} placeholder="Tu usuario"/>
          <Field label="Contraseña" value={pwd} onChange={v=>setPwd(v)} type="password" placeholder="••••••"/>
          <Btn onClick={login} disabled={!usr||!pwd}>Entrar →</Btn>
        </Card>
      </div>
    </div>
  );
}

// ── ADMIN HOME ─────────────────────────────────────────────────────────────────
function AdminHome({onGo,onLogout,session,products,orders,registers}){
  const todayO=orders.filter(o=>o.date===today());
  const openO=todayO.filter(o=>o.status==="open");
  const closedO=todayO.filter(o=>o.status==="closed");
  const tiles=[
    {id:"plan",      icon:"📋",label:"Plan de Producción", sub:"Órdenes y planificación",       accent:C.blue},
    {id:"registro",  icon:"⏱️",label:"Registrar Tiempo",   sub:openO.length>0?`${openO.length} orden(es) activa(s)`:"Sin órdenes abiertas hoy", accent:C.accent},
    {id:"cerrar",    icon:"📦",label:"Cerrar Producción",   sub:openO.length>0?`${openO.length} pendiente(s)`:"Todo cerrado hoy", accent:C.green},
    {id:"resultados",icon:"🏁",label:"Resultados del Día",  sub:`${closedO.length} lotes cerrados hoy`, accent:C.yellow},
    {id:"stats",     icon:"📊",label:"Estadísticas",        sub:"Rendimiento y tiempos",          accent:C.purple},
    {id:"config",    icon:"⚙️",label:"Configuración",       sub:`${products.length} artículos · usuarios`, accent:C.muted},
  ];
  return(
    <div style={{fontFamily:F.b,minHeight:"100vh",background:"#f0f2f5"}}>
      <div style={{background:C.card,padding:"16px 16px 14px",borderBottom:`3px solid ${C.accent}`,display:"flex",alignItems:"center",justifyContent:"space-between",boxShadow:"0 2px 8px rgba(0,0,0,0.08)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,flex:1}}>
          <WikukBrand dark={true} size="small"/>
          <div style={{marginLeft:"auto",textAlign:"right"}}>
            <p style={{color:C.muted,fontSize:12,margin:0}}>{fmtD(today())}</p>
            <p style={{color:C.text,fontSize:13,margin:0,fontWeight:600}}>{session.name}</p>
          </div>
        </div>
        <button onClick={onLogout} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"6px 12px",fontFamily:F.h,fontSize:14,cursor:"pointer"}}>Salir</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,padding:"14px 14px 6px"}}>
        {[{v:todayO.length,l:"Órdenes hoy",c:C.blue},{v:openO.length,l:"Abiertas",c:C.accent},{v:closedO.length,l:"Cerradas",c:C.green}].map(s=>(
          <Card key={s.l} style={{padding:"12px 8px",textAlign:"center"}}>
            <div style={{fontFamily:F.h,fontWeight:800,fontSize:30,color:s.c}}>{s.v}</div>
            <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:0.4}}>{s.l}</div>
          </Card>
        ))}
      </div>
      <div style={{padding:"12px 12px 30px",display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:8}}>
        {tiles.map(t=>(
          <button key={t.id} onClick={()=>onGo(t.id)} style={{background:C.card,border:`1.5px solid ${C.border}`,borderRadius:14,padding:"18px 16px",display:"flex",alignItems:"center",gap:14,cursor:"pointer",textAlign:"left",boxShadow:"0 1px 3px rgba(0,0,0,0.05)"}}>
            <span style={{fontSize:30,flexShrink:0}}>{t.icon}</span>
            <span style={{flex:1,minWidth:0}}>
              <div style={{fontFamily:F.h,fontWeight:800,fontSize:19,color:C.text,letterSpacing:0.3}}>{t.label}</div>
              <div style={{color:C.muted,fontSize:13,marginTop:2,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{t.sub}</div>
            </span>
            <span style={{color:C.border,fontSize:18}}>›</span>
          </button>
        ))}
      </div>
    </div>
  );
}

// ── OPERATOR HOME ──────────────────────────────────────────────────────────────
function OperatorHome({onGo,onLogout,session,orders,registers}){
  const todayRegs=registers.filter(r=>r.date===today()&&r.operatorName===session.name);
  const openO=orders.filter(o=>o.date===today()&&o.status==="open");
  return(
    <div style={{fontFamily:F.b,minHeight:"100vh",background:C.bg,display:"flex",flexDirection:"column"}}>
      <div style={{background:C.card,padding:"14px 16px",borderBottom:`3px solid ${C.accent}`,display:"flex",alignItems:"center",justifyContent:"space-between",boxShadow:"0 2px 8px rgba(0,0,0,0.08)"}}>
        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-start",gap:6}}>
          <WikukBrand dark={true} size="small"/>
          <h1 style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text,letterSpacing:1,margin:0}}>HOLA, {session.name.toUpperCase()}</h1>
          <p style={{color:C.muted,fontSize:12,margin:0}}>{fmtD(today())}</p>
        </div>
        <button onClick={onLogout} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"6px 12px",fontFamily:F.h,fontSize:14,cursor:"pointer"}}>Salir</button>
      </div>
      <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,gap:16}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,width:"100%",marginBottom:8}}>
          {[{v:openO.length,l:"Órdenes activas",c:C.accent},{v:todayRegs.length,l:"Mis registros hoy",c:C.green}].map(s=>(
            <Card key={s.l} style={{padding:"16px 10px",textAlign:"center"}}>
              <div style={{fontFamily:F.h,fontWeight:800,fontSize:36,color:s.c}}>{s.v}</div>
              <div style={{fontSize:12,color:C.muted,textTransform:"uppercase",letterSpacing:0.4}}>{s.l}</div>
            </Card>
          ))}
        </div>
        {openO.length===0
          ?<div style={{textAlign:"center",color:C.muted,padding:"20px 0"}}>
            <div style={{fontSize:48,marginBottom:8}}>⏳</div>
            <p style={{fontFamily:F.h,fontSize:16}}>Sin órdenes activas hoy.<br/>Consulta con tu supervisor.</p>
          </div>
          :<button onClick={()=>onGo("registro")} style={{width:"100%",background:C.accent,border:"none",borderRadius:18,padding:"28px 20px",cursor:"pointer",textAlign:"center"}}>
            <div style={{fontSize:44,marginBottom:8}}>⏱️</div>
            <div style={{fontFamily:F.h,fontWeight:800,fontSize:26,color:"#fff",letterSpacing:1}}>REGISTRAR TIEMPO</div>
            <div style={{color:"#fed7aa",fontSize:14,marginTop:4}}>{openO.length} orden(es) activa(s)</div>
          </button>
        }
      </div>
    </div>
  );
}

// ── PLAN DE PRODUCCIÓN ─────────────────────────────────────────────────────────
function PlanScreen({onBack,onGo,products,orders,registers,onSaveOrders}){
  const [period,setPeriod]=useState("semana");
  const [view,setView]=useState("ordenes"); // "ordenes" | "recursos"

  const getRange=()=>{
    if(period==="hoy")   return[today(),today()];
    if(period==="semana")return[weekStart(),addDays(weekStart(),6)];
    if(period==="mes")   return[monthStart(),addDays(monthStart(),30)];
    return[today(),addDays(today(),89)]; // trimestre
  };
  const[s,e]=getRange();
  const periodOrders=orders.filter(o=>o.date>=s&&o.date<=e);
  const openOrders=orders.filter(o=>o.date===today()&&o.status==="open");
  // Órdenes cerradas de ayer con procesos diferidos sin registrar
  const yesterday=addDays(today(),-1);
  const deferredOrders=orders.filter(o=>o.date===yesterday&&o.status==="closed").filter(o=>{
    const prod=products.find(p=>p.id===o.productId);
    const dProcs=prod?.processes?.filter(p=>p.deferred)||[];
    const regs=registers.filter(r=>r.orderId===o.id&&r.date===today());
    return dProcs.some(dp=>!regs.find(r=>r.processId===dp.id));
  });

  // Acumular materias primas y tiempos para el período
  const matAcc={};
  const timeAcc={};
  periodOrders.forEach(o=>{
    const prod=products.find(p=>p.id===o.productId);
    if(!prod||!o.qty)return;
    prod.materials?.forEach(m=>{
      const k=`${m.name}__${m.unit}`;
      if(!matAcc[k])matAcc[k]={name:m.name,unit:m.unit,total:0};
      matAcc[k].total+=m.qtyPerUnit*o.qty;
    });
    prod.processes?.forEach(pr=>{
      if(!timeAcc[pr.name])timeAcc[pr.name]={name:pr.name,totalMin:0};
      timeAcc[pr.name].totalMin+=pr.timeTarget*o.qty;
    });
  });
  const matList=Object.values(matAcc).map(m=>({...m,total:+m.total.toFixed(3)}));
  const timeList=Object.values(timeAcc).map(t=>({...t,totalH:+(t.totalMin/60).toFixed(1)}));

  const del=id=>{
    if(orders.find(x=>x.id===id)?.status==="closed")return alert("No se puede eliminar una orden cerrada.");
    if(window.confirm("¿Eliminar esta orden?"))onSaveOrders(orders.filter(x=>x.id!==id));
  };

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title="PLAN DE PRODUCCIÓN" onBack={onBack}/>
      <div style={{padding:14}}>
        <Btn onClick={()=>onGo("plan-new")} style={{marginBottom:14}}>＋ Nueva Orden</Btn>

        {/* Period filter */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:6,marginBottom:12}}>
          {["hoy","semana","mes","trimestre"].map(p=>(
            <button key={p} onClick={()=>setPeriod(p)} style={{padding:"10px 4px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:15,cursor:"pointer",border:"none",background:"#fff",color:period===p?C.accent:C.muted,border:`1.5px solid ${period===p?C.accent:C.border}`,textTransform:"uppercase",letterSpacing:0.3}}>{p}</button>
          ))}
        </div>

        {/* View toggle */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:14}}>
          {[["ordenes","📋 Órdenes"],["recursos","📦 Recursos necesarios"]].map(([v,l])=>(
            <button key={v} onClick={()=>setView(v)} style={{padding:"11px 8px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:15,cursor:"pointer",border:"none",background:"#fff",color:view===v?C.accent:C.muted,border:`1.5px solid ${view===v?C.accent:C.border}`}}>{l}</button>
          ))}
        </div>

        {view==="ordenes"&&(
          <>
            {periodOrders.length===0&&<div style={{textAlign:"center",padding:"40px 20px",color:C.muted}}><div style={{fontSize:48,marginBottom:12}}>📋</div><p style={{fontFamily:F.h,fontSize:18}}>Sin órdenes en este período</p></div>}
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {periodOrders.sort((a,b)=>a.date.localeCompare(b.date)).map(o=>{
                const prod=products.find(p=>p.id===o.productId);
                const regs=registers.filter(r=>r.orderId===o.id);
                const ops=[...new Set(regs.map(r=>r.operatorName))];
                return(
                  <Card key={o.id} color={o.status==="open"?`${C.green}55`:o.status==="closed"?C.border:`${C.blue}44`}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:10}}>
                      <div style={{flex:1}}>
                        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6,flexWrap:"wrap"}}>
                          <StatusPill status={o.status==="open"?"open":o.status==="closed"?"closed":"planned"}/>
                          <span style={{fontSize:13,color:C.muted}}>{fmtD(o.date)}</span>
                          {o.equipment&&<span style={{fontSize:12,color:C.blue,background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:20,padding:"2px 10px"}}>🔧 {o.equipment}</span>}
                        </div>
                        <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{prod?.name||"—"}</div>
                        <div style={{fontSize:13,color:C.muted,marginTop:4}}>
                          <span style={{color:C.accent,fontWeight:700}}>{o.qty} {prod?.unit||"ud"}</span>
                          {o.team?.length>0&&<span> · {o.team.join(", ")}</span>}
                          {regs.length>0&&<span> · {regs.length} registros</span>}
                        </div>
                      </div>
                      {o.status!=="closed"
                        ?<button onClick={()=>del(o.id)} style={{background:"#fff",border:`1.5px solid ${C.red}`,color:C.red,borderRadius:8,padding:"8px 10px",cursor:"pointer",fontSize:16,flexShrink:0}}>🗑️</button>
                        :o.date===today()&&<div style={{display:"flex",gap:6,flexShrink:0}}>
                          <button onClick={()=>onGo("edit-order",{ep:o})} style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"8px 10px",cursor:"pointer",fontSize:16}}>✏️</button>
                          <button onClick={()=>{if(window.confirm("¿Reabrir esta orden? Podrás añadir registros y volver a cerrarla."))onSaveOrders(orders.map(x=>x.id===o.id?{...x,status:"open",qtyActual:null,materialResults:null,yieldActual:null}:x));}} style={{background:"#fff",border:`1.5px solid ${C.green}`,color:C.green,borderRadius:8,padding:"8px 10px",cursor:"pointer",fontSize:13,fontFamily:F.h,fontWeight:700}}>↩ Reabrir</button>
                        </div>
                      }
                    </div>
                    {o.status==="closed"&&o.yieldActual!=null&&(
                      <div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${C.border}`,display:"flex",gap:10}}>
                        <div style={{textAlign:"center",flex:1,background:C.card2,borderRadius:8,padding:"8px 4px"}}>
                          <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:(o.yieldActual-o.yieldTarget)>=0?C.green:C.red}}>{o.yieldActual.toFixed(1)}%</div>
                          <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>Rendimiento</div>
                        </div>
                        <div style={{textAlign:"center",flex:1,background:C.card2,borderRadius:8,padding:"8px 4px"}}>
                          <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:(o.yieldActual-o.yieldTarget)>=0?C.green:C.red}}>{(o.yieldActual-o.yieldTarget)>=0?"+":""}{(o.yieldActual-o.yieldTarget).toFixed(1)}%</div>
                          <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>vs Objetivo</div>
                        </div>
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          </>
        )}

        {view==="recursos"&&(
          <div>
            <div style={{padding:"10px 12px",background:C.card2,borderRadius:10,marginBottom:14,fontSize:13,color:C.muted}}>
              Acumulado de <span style={{color:C.text,fontWeight:600}}>{periodOrders.length} órdenes</span> del período seleccionado
            </div>

            {matList.length===0&&timeList.length===0&&(
              <div style={{textAlign:"center",padding:"40px 20px",color:C.muted}}><div style={{fontSize:48,marginBottom:12}}>📦</div><p style={{fontFamily:F.h,fontSize:18}}>Sin datos de recursos<br/><span style={{fontSize:14}}>Configura materias primas y procesos en los artículos</span></p></div>
            )}

            {matList.length>0&&(
              <Card style={{marginBottom:14}}>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginBottom:12,letterSpacing:0.5}}>📦 MATERIAS PRIMAS NECESARIAS</div>
                {matList.map((m,i)=>(
                  <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                    <span style={{fontSize:15,color:C.text}}>{m.name}</span>
                    <span style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.blue}}>{m.total.toLocaleString()} <span style={{fontSize:13,fontWeight:400,color:C.muted}}>{m.unit}</span></span>
                  </div>
                ))}
              </Card>
            )}

            {timeList.length>0&&(
              <Card>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginBottom:12,letterSpacing:0.5}}>⏱️ TIEMPO NECESARIO POR PROCESO</div>
                {timeList.map((t,i)=>(
                  <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                    <span style={{fontSize:15,color:C.text}}>{t.name}</span>
                    <span style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.accent}}>{t.totalH}h <span style={{fontSize:13,fontWeight:400,color:C.muted}}>({t.totalMin} min)</span></span>
                  </div>
                ))}
                <div style={{marginTop:10,padding:"10px 12px",background:C.card2,borderRadius:8,display:"flex",justifyContent:"space-between"}}>
                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.muted}}>TOTAL</span>
                  <span style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.text}}>{(timeList.reduce((a,b)=>a+b.totalMin,0)/60).toFixed(1)}h</span>
                </div>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ── NUEVA ORDEN ────────────────────────────────────────────────────────────────
function PlanNewScreen({onBack,products,orders,users,onSaveOrders}){
  const [pid,setPid]           = useState("");
  const [qty,setQty]           = useState("");
  const [date,setDate]         = useState(today());
  const [equipment,setEquipment] = useState("");
  const [mi,setMi]             = useState("");
  const [team,setTeam]         = useState([]);
  const [saved,setSaved]       = useState(false);
  const prod=products.find(p=>p.id===pid);
  const qtyNum=parseFloat(qty)||0;

  // Operarios disponibles = usuarios con rol operator
  const availableOps=users.filter(u=>u.role==="operator");
  const addMember=(n)=>{const name=n||mi.trim();if(!name||team.includes(name))return;setTeam(t=>[...t,name]);setMi("");};

  const save=()=>{
    if(!pid)return alert("Selecciona un artículo");
    if(!qty||qtyNum<=0)return alert("Indica la cantidad a producir");
    onSaveOrders([...orders,{id:uid(),date,productId:pid,qty:qtyNum,equipment:equipment.trim(),team,status:"open",yieldTarget:prod?.yieldTarget||0,materialIn:null,materialOut:null,yieldActual:null}]);
    setSaved(true);setTimeout(()=>{setSaved(false);onBack();},1200);
  };

  const matPreview =qtyNum>0&&prod?.materials?.length >0?prod.materials.map(m =>({...m,needed:+(m.qtyPerUnit*qtyNum).toFixed(3)})):[];
  const timePreview=qtyNum>0&&prod?.processes?.length>0?prod.processes.map(pr=>({...pr,totalMin:pr.timeTarget*qtyNum,totalH:(pr.timeTarget*qtyNum/60).toFixed(1)})):[];
  const totalMinNeeded=timePreview.reduce((a,b)=>a+b.totalMin,0);
  const totalHNeeded=totalMinNeeded/60;

  // Horas disponibles del equipo asignado
  const teamHours=team.reduce((acc,name)=>{
    const u=users.find(x=>x.name===name);
    return acc+(u?.hoursPerDay||8);
  },0);
  const deficit=totalHNeeded-teamHours;

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title="NUEVA ORDEN" onBack={onBack}/>
      <div style={{padding:14}}>
        {saved&&<Toast msg="¡Orden creada!"/>}
        <Card style={{marginBottom:14}}>
          <Sel label="Artículo a producir" value={pid} onChange={v=>{setPid(v);setQty("");}} options={products.map(p=>({value:p.id,label:p.name}))} placeholder="Seleccionar artículo..."/>
          {prod&&<Field label={`Cantidad a producir (${prod.unit||"ud"})`} value={qty} onChange={setQty} type="number" placeholder={`Ej: 500 ${prod.unit||"ud"}`} min="1" step="1"/>}
          <Field label="Fecha de producción" value={date} onChange={setDate} type="date"/>
          <Field label="Equipo / Línea (opcional)" value={equipment} onChange={setEquipment} placeholder="Ej: Línea 1…"/>
        </Card>

        {/* Previsión materias y tiempos */}
        {prod&&qtyNum>0&&(matPreview.length>0||timePreview.length>0)&&(
          <Card style={{marginBottom:14,borderColor:`${C.blue}88`}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
              <span style={{fontSize:20}}>🔍</span>
              <div style={{fontFamily:F.h,fontWeight:800,fontSize:17,color:C.blue,letterSpacing:0.5}}>PREVISIÓN PARA {qtyNum} {prod.unit}</div>
            </div>
            {matPreview.length>0&&(
              <div style={{marginBottom:14}}>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,marginBottom:8,textTransform:"uppercase"}}>Materias primas</div>
                {matPreview.map(m=>(
                  <div key={m.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                    <span style={{fontSize:14,color:C.text}}>{m.name}</span>
                    <span style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.blue}}>{m.needed} <span style={{fontSize:12,color:C.muted}}>{m.unit}</span></span>
                  </div>
                ))}
              </div>
            )}
            {timePreview.length>0&&(
              <div>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,marginBottom:8,textTransform:"uppercase"}}>Tiempo estimado por proceso</div>
                {timePreview.map(pr=>(
                  <div key={pr.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                    <span style={{fontSize:14,color:C.text}}>{pr.name}</span>
                    <span style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.accent}}>{pr.totalH}h</span>
                  </div>
                ))}
                <div style={{marginTop:10,padding:"10px 12px",background:C.card2,borderRadius:8,display:"flex",justifyContent:"space-between"}}>
                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted}}>TOTAL HORAS NECESARIAS</span>
                  <span style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{totalHNeeded.toFixed(1)}h</span>
                </div>
              </div>
            )}
          </Card>
        )}

        {/* Equipo de trabajo */}
        <Card style={{marginBottom:14}}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.text,marginBottom:12}}>EQUIPO DE TRABAJO</div>

          {/* Chips de operarios ya registrados */}
          {availableOps.length>0&&(
            <div style={{marginBottom:12}}>
              <div style={{fontFamily:F.h,fontWeight:600,fontSize:13,color:C.muted,marginBottom:8,textTransform:"uppercase",letterSpacing:0.5}}>Operarios disponibles</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                {availableOps.map(u=>{
                  const inTeam=team.includes(u.name);
                  return(
                    <button key={u.id} onClick={()=>inTeam?setTeam(t=>t.filter(x=>x!==u.name)):addMember(u.name)}
                      style={{background:"#fff",border:`1.5px solid ${inTeam?C.green:C.border}`,color:inTeam?C.green:C.muted,borderRadius:20,padding:"6px 14px",fontSize:14,fontFamily:F.b,cursor:"pointer"}}>
                      {inTeam?"✓ ":""}{u.name} <span style={{fontSize:11,opacity:0.7}}>({u.hoursPerDay||8}h)</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Añadir operario manualmente si no está en la lista */}
          <div style={{fontFamily:F.h,fontWeight:600,fontSize:13,color:C.muted,marginBottom:8,textTransform:"uppercase",letterSpacing:0.5}}>O añadir manualmente</div>
          <div style={{display:"flex",gap:8,marginBottom:12}}>
            <input value={mi} onChange={e=>setMi(e.target.value)} onKeyDown={e=>e.key==="Enter"&&(e.preventDefault(),addMember())} placeholder="Otro nombre + Enter"
              style={{flex:1,background:C.card2,border:`1px solid ${C.border}`,color:C.text,borderRadius:10,padding:"11px 14px",fontFamily:F.b,fontSize:15,outline:"none"}}/>
            <button onClick={()=>addMember()} style={{background:C.accent,border:"none",color:"#fff",borderRadius:10,padding:"11px 16px",fontFamily:F.h,fontWeight:700,fontSize:18,cursor:"pointer"}}>＋</button>
          </div>

          {/* Resumen horas equipo */}
          {team.length>0&&totalHNeeded>0&&(
            <div style={{padding:"12px 14px",background:"#fff",border:`1.5px solid ${deficit>0?C.red:C.green}`,borderRadius:10}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:deficit!==0?10:0}}>
                <div style={{textAlign:"center"}}>
                  <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.text}}>{totalHNeeded.toFixed(1)}h</div>
                  <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>Necesarias</div>
                </div>
                <div style={{textAlign:"center"}}>
                  <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.green}}>{teamHours.toFixed(1)}h</div>
                  <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>Disponibles</div>
                </div>
                <div style={{textAlign:"center"}}>
                  <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:deficit>0?C.red:C.green}}>{deficit>0?"+":"−"}{Math.abs(deficit).toFixed(1)}h</div>
                  <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>{deficit>0?"Déficit":"Margen"}</div>
                </div>
              </div>
              {deficit>0&&<div style={{fontSize:13,color:C.red,fontFamily:F.h,fontWeight:600}}>⚠️ Faltan {deficit.toFixed(1)}h — considera añadir más operarios</div>}
              {deficit<=0&&<div style={{fontSize:13,color:C.green,fontFamily:F.h,fontWeight:600}}>✓ Equipo suficiente para el pedido</div>}
            </div>
          )}
        </Card>

        <Btn onClick={save} disabled={!pid||!qty||qtyNum<=0}>✅ Crear Orden</Btn>
      </div>
    </div>
  );
}

// ── REGISTRAR TIEMPO ───────────────────────────────────────────────────────────
function RegistroScreen({onBack,session,products,orders,registers,onSaveRegisters}){
  const openOrders=orders.filter(o=>o.date===today()&&o.status==="open");
  // Órdenes cerradas de ayer con procesos diferidos sin registrar
  const yesterday=addDays(today(),-1);
  const deferredOrders=orders.filter(o=>o.date===yesterday&&o.status==="closed").filter(o=>{
    const prod=products.find(p=>p.id===o.productId);
    const dProcs=prod?.processes?.filter(p=>p.deferred)||[];
    const regs=registers.filter(r=>r.orderId===o.id&&r.date===today());
    return dProcs.some(dp=>!regs.find(r=>r.processId===dp.id));
  });
  const hasOrders=openOrders.length>0;

  // modo: "orden" (con orden activa) | "manual" (sin orden)
  const [modo,setModo]=useState(hasOrders?"orden":"manual");

  // estado modo orden
  const [oid,setOid]=useState(openOrders.length===1?openOrders[0].id:"");

  // estado modo manual
  const [mpid,setMpid]=useState("");
  const [mprid,setMprid]=useState("");

  const [op,setOp]=useState(session?.role==="operator"?session.name:"");
  const [mins,setMins]=useState("");
  const [saved,setSaved]=useState(false);

  const order=orders.find(o=>o.id===oid);
  const prodOrden=order?products.find(p=>p.id===order.productId):null;
  const prodManual=products.find(p=>p.id===mpid);
  const prod=modo==="orden"?prodOrden:prodManual;
  const prid=modo==="orden"?oid&&prod?oid:"":mprid; // usamos estado separado abajo

  // proceso seleccionado según modo
  const [prid2,setPrid2]=useState("");
  const procesos=(modo==="orden"?prodOrden:prodManual)?.processes||[];

  const reset=()=>{
    setPrid2("");
    if(session?.role!=="operator")setOp("");
    setMins("");
    if(modo==="orden"){setOid(openOrders.length===1?openOrders[0].id:"");}
    else{setMpid("");setMprid("");}
  };

  const [qtyDone,setQtyDone]=useState("");

  const save=()=>{
    const productId=modo==="orden"?order?.productId:mpid;
    const operatorName=op.trim();
    if(!productId||!prid2||!operatorName||!mins)return alert("Completa todos los campos");
    onSaveRegisters([...registers,{
      id:uid(),date:today(),
      orderId:modo==="orden"?oid:null,
      productId,
      processId:prid2,
      operatorName,
      minutes:parseInt(mins),
      qtyDone:parseFloat(qtyDone)||null,
      manual:modo==="manual",
    }]);
    setSaved(true);
    reset();
    setQtyDone("");
    setTimeout(()=>setSaved(false),2000);
  };

  const todayRegs=registers.filter(r=>r.date===today()&&(modo==="orden"?r.orderId===oid:r.manual&&r.productId===mpid));
  const canSave=modo==="orden"?oid&&prid2&&op&&mins:mpid&&prid2&&op&&mins;

  return (
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title="REGISTRAR TIEMPO" onBack={onBack}/>
      <div style={{padding:14}}>
        {saved&&<Toast msg="¡Registro guardado!"/>}

        {/* Toggle modo */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
          <button onClick={()=>{setModo("orden");setPrid2("");}} style={{padding:"12px 8px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:16,cursor:"pointer",border:"none",background:"#fff",color:modo==="orden"?C.accent:C.muted,border:`1.5px solid ${modo==="orden"?C.accent:C.border}`}}>
            📋 Con Orden
          </button>
          <button onClick={()=>{setModo("manual");setPrid2("");}} style={{padding:"12px 8px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:16,cursor:"pointer",border:"none",background:"#fff",color:modo==="manual"?C.accent:C.muted,border:`1.5px solid ${modo==="manual"?C.accent:C.border}`}}>
            ✏️ Manual
          </button>
        </div>

        <Card style={{marginBottom:14}}>
          {modo==="orden"?(
            <>
              {openOrders.length===0&&(
                <div style={{padding:"10px 12px",background:"#fffbf5",border:`1px solid ${C.accent}`,borderRadius:8,marginBottom:14,fontSize:13,color:C.accent}}>
                  ⚠️ Sin órdenes abiertas hoy — usa el modo Manual
                </div>
              )}
              <Sel label="Orden de producción" value={oid} onChange={v=>{setOid(v);setPrid2("");if(session?.role!=="operator")setOp("");}}
                options={[
              ...openOrders.map(o=>{const p=products.find(x=>x.id===o.productId);return{value:o.id,label:`${p?.name||"—"}${o.equipment?" · "+o.equipment:""} (${o.qty} ${p?.unit||"ud"})`};}),
              ...deferredOrders.map(o=>{const p=products.find(x=>x.id===o.productId);return{value:o.id,label:`⏭ ${p?.name||"—"} (diferido de ayer)`};})
            ]}
                placeholder="Seleccionar orden..."/>
              {order?.team?.length>0&&<div style={{marginBottom:14,padding:"8px 12px",background:C.card2,borderRadius:8,fontSize:13,color:C.muted}}>Equipo: <span style={{color:C.text}}>{order.team.join(", ")}</span></div>}

              {/* Estado de procesos de esta orden */}
              {prodOrden?.processes?.length>0&&(()=>{
                const orderRegs=registers.filter(r=>r.orderId===oid);
                const regByProc={};
                orderRegs.forEach(r=>{
                  if(!regByProc[r.processId])regByProc[r.processId]={count:0,totalMins:0,totalQty:0};
                  regByProc[r.processId].count++;
                  regByProc[r.processId].totalMins+=r.minutes;
                  regByProc[r.processId].totalQty+=(r.qtyDone||0);
                });
                const pending=prodOrden.processes.filter(p=>!regByProc[p.id]);
                const done=prodOrden.processes.filter(p=>regByProc[p.id]);
                return(
                  <div style={{marginBottom:14,border:`1px solid ${pending.length>0?C.border:`${C.green}66`}`,borderRadius:10,overflow:"hidden"}}>
                    <div style={{padding:"8px 12px",background:pending.length===0?C.greenBg:"#f8f8f8",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <span style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:pending.length===0?C.green:C.muted,textTransform:"uppercase",letterSpacing:0.5}}>
                        {pending.length===0?"✅ Todos los procesos registrados":`⭕ ${pending.length} proceso(s) pendiente(s)`}
                      </span>
                      <span style={{fontSize:12,color:C.muted}}>{done.length}/{prodOrden.processes.length}</span>
                    </div>
                    {prodOrden.processes.map(p=>{
                      const r=regByProc[p.id];
                      const isDone=!!r;
                      return(
                        <div key={p.id} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"7px 12px",borderTop:`1px solid ${C.border}`,background:isDone?C.greenBg:"#fff"}}>
                          <div style={{display:"flex",alignItems:"center",gap:8}}>
                            <span style={{fontSize:15}}>{isDone?"✅":"⭕"}</span>
                            <span style={{fontFamily:F.h,fontWeight:600,fontSize:15,color:isDone?C.green:C.text}}>{p.name}</span>
                          </div>
                          {isDone
                            ?<span style={{fontSize:12,color:C.green}}>{r.totalMins} min{r.totalQty>0?` · ${r.totalQty} ${prodOrden.unit||"ud"}`:""}</span>
                            :<span style={{fontSize:12,color:C.accent}}>Pendiente</span>
                          }
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </>
          ):(
            <>
              <div style={{padding:"10px 12px",background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:8,marginBottom:14,fontSize:13,color:C.muted}}>
                ✏️ Registro sin orden asignada — elige artículo y proceso libremente
              </div>
              <Sel label="Artículo" value={mpid} onChange={v=>{setMpid(v);setPrid2("");}} options={products.map(p=>({value:p.id,label:p.name}))} placeholder="Seleccionar artículo..."/>
            </>
          )}

          <Sel label="Proceso" value={prid2} onChange={setPrid2}
            options={procesos.map(p=>({value:p.id,label:`${p.name}  (obj: ${p.timeTarget} min)`}))}
            placeholder={(modo==="orden"?oid:mpid)?"Seleccionar proceso...":"— Primero selecciona —"}/>

          {session?.role==="operator"
            ?<div style={{marginBottom:14,padding:"10px 12px",background:C.card2,borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>👤 {session.name}</div>
            :modo==="orden"&&order?.team?.length>0
              ?<Sel label="Operario" value={op} onChange={setOp} options={order.team.map(m=>({value:m,label:m}))} placeholder="Seleccionar operario..."/>
              :<Field label="Operario" value={op} onChange={setOp} placeholder="Nombre del operario"/>
          }
          <Field label="Tiempo realizado (minutos)" value={mins} onChange={setMins} type="number" placeholder="Ej: 35" min="1"/>
          <Field
            label={`Cantidad elaborada en este proceso (${(modo==="orden"?prodOrden:prodManual)?.unit||"ud"})`}
            value={qtyDone} onChange={setQtyDone}
            type="number" placeholder="Ej: 80" min="0" step="1"/>
          {/* Comparativa inmediata tiempo vs objetivo */}
          {qtyDone&&parseFloat(qtyDone)>0&&prid2&&(()=>{
            const prodRef=modo==="orden"?prodOrden:prodManual;
            const proc=prodRef?.processes?.find(p=>p.id===prid2);
            const q=parseFloat(qtyDone);
            const objMins=proc?Math.round(proc.timeTarget*q):null;
            const realMins=parseInt(mins)||0;
            const diff=objMins!=null&&realMins>0?realMins-objMins:null;
            if(!objMins)return null;
            return(
              <div style={{padding:"10px 12px",background:"#fff",border:`1.5px solid ${diff!=null&&diff<=0?C.green:diff!=null?C.red:C.border}`,borderRadius:8,marginBottom:14}}>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:6,textTransform:"uppercase",letterSpacing:0.5}}>Previsión para {q} {prodRef?.unit||"ud"}</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr"+(diff!=null?" 1fr":""),gap:8}}>
                  <div style={{textAlign:"center",background:"rgba(0,0,0,0.2)",borderRadius:6,padding:"6px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{objMins} min</div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Objetivo</div>
                  </div>
                  {realMins>0&&<div style={{textAlign:"center",background:"rgba(0,0,0,0.2)",borderRadius:6,padding:"6px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{realMins} min</div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Real</div>
                  </div>}
                  {diff!=null&&<div style={{textAlign:"center",background:"rgba(0,0,0,0.2)",borderRadius:6,padding:"6px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:diff<=0?C.green:C.red}}>{diff>0?"+":""}{diff} min</div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>{diff<=0?"✓ Adelanto":"⚠ Retraso"}</div>
                  </div>}
                </div>
              </div>
            );
          })()}
        </Card>

        <Btn onClick={save} disabled={!canSave} style={{marginBottom:20}}>⏱️ Guardar Registro</Btn>

        {todayRegs.length>0&&(
          <>
            {/* Resumen por proceso con qty y comparativa */}
            {(()=>{
              const totalMins=todayRegs.reduce((a,r)=>a+r.minutes,0);
              const byProc={};
              todayRegs.forEach(r=>{
                const prodRef=products.find(p=>p.id===r.productId);
                const pr=prodRef?.processes?.find(p=>p.id===r.processId);
                const key=pr?.id||r.processId||"?";
                if(!byProc[key])byProc[key]={name:pr?.name||"?",targetPerUnit:pr?.timeTarget||0,unit:prodRef?.unit||"ud",totalMins:0,totalQty:0};
                byProc[key].totalMins+=r.minutes;
                byProc[key].totalQty+=(r.qtyDone||0);
              });
              return(
                <Card style={{padding:"12px 14px",marginBottom:10}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                    <span style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,textTransform:"uppercase",letterSpacing:0.5}}>Resumen del día</span>
                    <span style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.accent}}>{(totalMins/60).toFixed(1)}h total</span>
                  </div>
                  {Object.values(byProc).map(p=>{
                    const objMins=p.totalQty>0?Math.round(p.totalQty*p.targetPerUnit):null;
                    const diff=objMins!=null?p.totalMins-objMins:null;
                    return(
                      <div key={p.name} style={{padding:"8px 0",borderTop:`1px solid ${C.border}`}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:3}}>
                          <span style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{p.name}</span>
                          <span style={{fontFamily:F.h,fontWeight:800,fontSize:16,color:C.text}}>{p.totalMins} min</span>
                        </div>
                        <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                          {p.totalQty>0&&<span style={{fontSize:12,color:C.blue}}>{p.totalQty} {p.unit}</span>}
                          {objMins!=null&&<span style={{fontSize:12,color:C.muted}}>obj: {objMins} min</span>}
                          {diff!=null&&<span style={{fontSize:12,fontWeight:700,color:diff<=0?C.green:C.red}}>{diff>0?"+":""}{diff} min {diff<=0?"✓":"⚠"}</span>}
                        </div>
                      </div>
                    );
                  })}
                </Card>
              );
            })()}
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,letterSpacing:0.5,textTransform:"uppercase",marginBottom:8}}>
              Registros de hoy ({todayRegs.length})
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {[...todayRegs].reverse().map(r=>{
                const p=products.find(x=>x.id===r.productId);
                const pr=p?.processes?.find(x=>x.id===r.processId);
                const diff=pr?r.minutes-pr.timeTarget:null;
                return(
                  <Card key={r.id} style={{padding:"12px 14px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{flex:1}}>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{r.operatorName}</div>
                        <div style={{fontSize:13,color:C.muted}}>{p?.name||"—"} · {pr?.name||"—"}{r.manual&&<span style={{color:C.blue,marginLeft:6}}>✏️</span>}</div>
                        {r.qtyDone>0&&pr&&(()=>{
                          const objM=Math.round(r.qtyDone*pr.timeTarget);
                          const d=r.minutes-objM;
                          return <div style={{marginTop:3,fontSize:12,color:C.muted}}>{r.qtyDone} {p?.unit||"ud"} · obj {objM} min · <span style={{color:d<=0?C.green:C.red,fontWeight:700}}>{d>0?"+":""}{d} min {d<=0?"✓":"⚠"}</span></div>;
                        })()}
                      </div>
                      <div style={{textAlign:"right",flexShrink:0,marginLeft:10}}>
                        <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{r.minutes} min</div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ── CERRAR PRODUCCIÓN ──────────────────────────────────────────────────────────
function CerrarScreen({onBack,products,orders,registers,onSaveOrders}){
  const openOrders=orders.filter(o=>o.date===today()&&o.status==="open");
  // Órdenes cerradas de ayer con procesos diferidos sin registrar
  const yesterday=addDays(today(),-1);
  const deferredOrders=orders.filter(o=>o.date===yesterday&&o.status==="closed").filter(o=>{
    const prod=products.find(p=>p.id===o.productId);
    const dProcs=prod?.processes?.filter(p=>p.deferred)||[];
    const regs=registers.filter(r=>r.orderId===o.id&&r.date===today());
    return dProcs.some(dp=>!regs.find(r=>r.processId===dp.id));
  });
  const [oid,setOid]=useState(openOrders.length===1?openOrders[0].id:"");
  const [qtyActual,setQtyActual]=useState("");   // unidades realmente producidas
  const [matInputs,setMatInputs]=useState({});   // {matId: consumido_real}
  const [saved,setSaved]=useState(false);

  const order=orders.find(o=>o.id===oid);
  const prod=order?products.find(p=>p.id===order.productId):null;
  const regs=registers.filter(r=>r.orderId===oid);
  const ops=[...new Set(regs.map(r=>r.operatorName))];
  const qtyNum=parseFloat(qtyActual)||0;

  // Para cada materia prima: esperado = qtyActual × qtyPerUnit
  // Rendimiento por mat = (esperado / consumido_real) × 100
  const matResults=(prod?.materials||[]).map(m=>{
    const expected=+(m.qtyPerUnit*qtyNum).toFixed(3);
    const actual=parseFloat(matInputs[m.id])||0;
    const yieldPct=actual>0?+((expected/actual)*100).toFixed(1):null;
    const waste=actual>0?+(actual-expected).toFixed(3):null;
    return{...m,expected,actual,yieldPct,waste};
  });

  // Rendimiento global = media de los rendimientos de materias primas
  const validYields=matResults.filter(m=>m.yieldPct!==null);
  const globalYield=validYields.length>0
    ?+(validYields.reduce((a,m)=>a+m.yieldPct,0)/validYields.length).toFixed(1)
    :null;
  const yDiff=globalYield!=null?(globalYield-order?.yieldTarget).toFixed(1):null;

  const procSum={};
  regs.forEach(r=>{const pr=prod?.processes?.find(p=>p.id===r.processId);if(!pr)return;const k=pr.name.toLowerCase().trim();if(!procSum[k])procSum[k]={name:pr.name,targetPerUnit:pr.timeTarget,total:0};procSum[k].total+=r.minutes;});

  // Total unidades elaboradas registradas
  // Solo el proceso que define la cantidad determina el total de referencia
  const defProc=prod?.processes?.find(p=>p.definesQty);
  const totalQtyRegs=defProc
    ?regs.filter(r=>r.processId===defProc.id).reduce((a,r)=>a+(r.qtyDone||0),0)
    :null; // null = ningún proceso marcado como definitorio

  // Verificar qué procesos tienen registros y cuáles faltan
  const registeredProcessIds = new Set(regs.map(r => r.processId));
  // Solo exige procesos del mismo día (no diferidos)
  const requiredProcs = (prod?.processes || []).filter(p => !p.deferred);
  const missingProcs = requiredProcs.filter(p => !registeredProcessIds.has(p.id));
  const allProcsRegistered = missingProcs.length === 0;
  const deferredProcs = (prod?.processes || []).filter(p => p.deferred);

  const canClose = oid && qtyNum > 0
    && (prod?.materials?.length === 0 || matResults.every(m => m.actual > 0))
    && allProcsRegistered;

  const close=()=>{
    if(!oid || !qtyNum) return alert("Indica la cantidad producida");
    if(!allProcsRegistered) return alert(`Faltan registros de tiempo en: ${missingProcs.map(p=>p.name).join(", ")}`);
    if(prod?.materials?.length > 0 && !matResults.every(m => m.actual > 0)) return alert("Introduce el consumo de todas las materias primas");
    onSaveOrders(orders.map(o=>o.id===oid?{
      ...o,status:"closed",
      qtyActual:qtyNum,
      materialResults:matResults,
      yieldActual:globalYield??0,
    }:o));
    setQtyActual("");setMatInputs({});setOid("");
    setSaved(true);setTimeout(()=>setSaved(false),2500);
  };

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title="CERRAR PRODUCCIÓN" onBack={onBack}/>
      <div style={{padding:14}}>
        {saved&&<Toast msg="¡Producción cerrada!"/>}
        {openOrders.length===0&&<div style={{background:"#fff",border:`1px solid ${C.blue}`,borderRadius:12,padding:16,marginBottom:14}}><div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.blue}}>ℹ️ No hay órdenes abiertas hoy</div></div>}

        <Card style={{marginBottom:14}}>
          <Sel label="Orden a cerrar" value={oid}
            onChange={v=>{setOid(v);setQtyActual("");setMatInputs({});}}
            options={openOrders.map(o=>{const p=products.find(x=>x.id===o.productId);return{value:o.id,label:`${p?.name||"—"}${o.equipment?" · "+o.equipment:""} (${o.qty} ${p?.unit||"ud"})`};})}
            placeholder="Seleccionar orden..."/>

          {prod&&(
            <>
              {defProc&&totalQtyRegs>0&&(
                <div style={{padding:"8px 12px",background:C.card2,borderRadius:8,marginBottom:14,fontSize:13,color:C.muted}}>
                  Proceso <span style={{color:C.green,fontWeight:700}}>{defProc.name}</span> (proceso definitorio): <span style={{color:C.green,fontWeight:700}}>{totalQtyRegs} {prod.unit}</span>
                </div>
              )}
              {!defProc&&<div style={{padding:"8px 12px",background:"#fffbf5",border:`1px solid ${C.accent}44`,borderRadius:8,marginBottom:14,fontSize:13,color:C.accent}}>
                ⚠️ Marca un proceso como definitorio en la configuración del artículo
              </div>}
              <Field
                label={`Cantidad total producida (${prod.unit})`}
                value={qtyActual} onChange={setQtyActual}
                type="number" placeholder={`Ej: ${order?.qty||100}`} min="0" step="1"/>
            </>
          )}
        </Card>

        {/* Materias primas: consumo real */}
        {prod?.materials?.length>0&&qtyNum>0&&(
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginBottom:4}}>CONSUMO DE MATERIAS PRIMAS</div>
            <div style={{fontSize:13,color:C.muted,marginBottom:14}}>Esperado para {qtyNum} {prod.unit} → introduce lo consumido realmente</div>
            {matResults.map(m=>(
              <div key={m.id} style={{marginBottom:14,paddingBottom:14,borderBottom:`1px solid ${C.border}`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{m.name}</span>
                  <span style={{fontSize:13,color:C.muted}}>Esperado: <span style={{color:C.blue}}>{m.expected} {m.unit}</span></span>
                </div>
                <Field
                  label={`Consumido realmente (${m.unit})`}
                  value={matInputs[m.id]||""}
                  onChange={v=>setMatInputs(prev=>({...prev,[m.id]:v}))}
                  type="number" placeholder={`${m.expected}`} min="0" step="0.001"/>
                {m.yieldPct!==null&&(
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
                    <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"8px 4px"}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:m.yieldPct>=order?.yieldTarget?C.green:C.red}}>{m.yieldPct}%</div>
                      <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Rendimiento</div>
                    </div>
                    <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"8px 4px"}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{m.expected} {m.unit}</div>
                      <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Esperado</div>
                    </div>
                    <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"8px 4px"}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:m.waste>0?C.red:C.green}}>{m.waste>0?"+":""}{m.waste} {m.unit}</div>
                      <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>{m.waste>0?"Exceso":"Ahorro"}</div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </Card>
        )}

        {/* Resumen global */}
        {globalYield!==null&&order&&(
          <Card style={{marginBottom:14,borderColor:parseFloat(yDiff)>=0?C.green:C.red}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,letterSpacing:0.5,textTransform:"uppercase",marginBottom:12}}>Resumen del cierre</div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
              <div style={{textAlign:"center",padding:14,background:C.card2,borderRadius:10}}>
                <div style={{fontFamily:F.h,fontWeight:800,fontSize:34,color:C.text}}>{globalYield}%</div>
                <div style={{fontSize:12,color:C.muted,textTransform:"uppercase"}}>Rendimiento</div>
              </div>
              <div style={{textAlign:"center",padding:14,background:C.card2,borderRadius:10}}>
                <div style={{fontFamily:F.h,fontWeight:800,fontSize:34,color:parseFloat(yDiff)>=0?C.green:C.red}}>{parseFloat(yDiff)>=0?"+":""}{yDiff}%</div>
                <div style={{fontSize:12,color:C.muted,textTransform:"uppercase"}}>vs Obj ({order.yieldTarget}%)</div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
              <div style={{textAlign:"center",padding:10,background:C.card2,borderRadius:8}}>
                <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.text}}>{order.qty} {prod?.unit}</div>
                <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>Planificadas</div>
              </div>
              <div style={{textAlign:"center",padding:10,background:C.card2,borderRadius:8}}>
                <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:C.accent}}>{qtyNum} {prod?.unit}</div>
                <div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>Producidas</div>
              </div>
            </div>
            {ops.length>0&&<div style={{padding:"10px 12px",background:C.card2,borderRadius:10,marginBottom:10}}>
              <div style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:6}}>OPERARIOS</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:6}}>{ops.map(o=><span key={o} style={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:20,padding:"4px 12px",fontSize:13,color:C.text}}>{o}</span>)}</div>
            </div>}
            {Object.values(procSum).length>0&&(
              <div style={{padding:"10px 12px",background:C.card2,borderRadius:10}}>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:8}}>TIEMPOS vs OBJETIVO</div>
                {Object.values(procSum).map(ps=>{
                  const expected=qtyNum>0?Math.round(qtyNum*ps.targetPerUnit):null;
                  const d=expected!=null?ps.total-expected:null;
                  const pct=expected&&expected>0?Math.round((ps.total/expected)*100):null;
                  return(
                    <div key={ps.name} style={{padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                        <span style={{color:C.text,fontSize:14,fontFamily:F.h,fontWeight:600}}>{ps.name}</span>
                        <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{ps.total} min</span>
                      </div>
                      {expected!=null&&(
                        <div style={{display:"flex",gap:8}}>
                          <span style={{fontSize:12,color:C.muted}}>Obj ({qtyNum} {prod?.unit}): {expected} min</span>
                          <span style={{fontSize:12,fontWeight:700,color:d<=0?C.green:C.red}}>{d>0?"+":""}{d} min ({pct}%)</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        )}

        {/* Checklist de procesos */}
        {prod && regs.length >= 0 && prod.processes?.length > 0 && (
          <Card style={{marginBottom:14, borderColor: allProcsRegistered ? `${C.green}88` : `${C.red}88`}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,letterSpacing:0.5,textTransform:"uppercase",marginBottom:10}}>
              {allProcsRegistered ? "✅ Procesos del día completos" : "⚠️ Procesos pendientes de registrar"}
            </div>
            {deferredProcs.length>0&&(
              <div style={{padding:"8px 12px",background:"#fffbf0",border:`1.5px solid #b45309`,borderRadius:8,marginBottom:10,fontSize:13,color:"#b45309",fontFamily:F.h,fontWeight:600}}>
                ⏭ {deferredProcs.map(p=>p.name).join(", ")} → se registrará mañana
              </div>
            )}
            {prod.processes.map(p => {
              const done = registeredProcessIds.has(p.id);
              const procRegs = regs.filter(r => r.processId === p.id);
              const totalMins = procRegs.reduce((a,r) => a + r.minutes, 0);
              return (
                <div key={p.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{fontSize:16}}>{done ? "✅" : "⭕"}</span>
                    <span style={{fontFamily:F.h,fontWeight:600,fontSize:16,color:done?C.text:C.red}}>{p.name}</span>
                  </div>
                  <span style={{fontSize:13,color:done?C.muted:C.red}}>
                    {done ? `${totalMins} min · ${procRegs.length} reg.` : "Sin registros"}
                  </span>
                </div>
              );
            })}
          </Card>
        )}

        <Btn onClick={close} disabled={!canClose} v="green">📦 Confirmar Cierre</Btn>
      </div>
    </div>
  );
}

// ── RESULTADOS DEL DÍA ─────────────────────────────────────────────────────────
function ResultadosScreen({onBack,products,orders,registers,users=[]}){
  const todayOrders=orders.filter(o=>o.date===today());
  const closed=todayOrders.filter(o=>o.status==="closed");
  const open=todayOrders.filter(o=>o.status==="open");
  const avgYield=closed.length?(closed.reduce((a,b)=>a+b.yieldActual,0)/closed.length).toFixed(1):null;
  const todayRegs=registers.filter(r=>r.date===today());
  const allOps=new Set(todayRegs.map(r=>r.operatorName));

  // ── Balanza económica real vs objetivo ────────────────────────────────────
  const ecoData=closed.map(o=>{
    const prod=products.find(p=>p.id===o.productId);
    const regsO=registers.filter(r=>r.orderId===o.id);
    let matReal=0,matObj=0;
    (o.materialResults||[]).forEach(m=>{
      const matDef=prod?.materials?.find(x=>x.name===m.name);
      const price=matDef?.pricePerUnit||0;
      matReal+=(m.actual||0)*price;
      matObj+=(m.expected||0)*price;
    });
    let moReal=0,moObj=0;
    regsO.forEach(r=>{
      const u=users.find(x=>x.name===r.operatorName);
      const rate=(u?.costPerHour||0)/60;
      moReal+=r.minutes*rate;
    });
    const avgRate=users.filter(u=>u.role==="operator"&&u.costPerHour>0).reduce((a,u,_,arr)=>a+u.costPerHour/arr.length,0)/60;
    if(o.qtyActual&&prod){
      prod.processes?.forEach(pr=>{if(!pr.deferred)moObj+=o.qtyActual*pr.timeTarget*avgRate;});
    }
    return{name:prod?.name||"—",matReal,matObj,moReal,moObj,totalReal:matReal+moReal,totalObj:matObj+moObj};
  });
  const totReal=ecoData.reduce((a,e)=>a+e.totalReal,0);
  const totObj=ecoData.reduce((a,e)=>a+e.totalObj,0);
  const totDiff=totReal-totObj;
  const hayCostes=totReal>0||totObj>0;

  // ── Resumen de procesos del día (agrupado por nombre de proceso) ─────────
  const dayProcSum={};
  closed.forEach(o=>{
    const prod=products.find(p=>p.id===o.productId);
    const regs=registers.filter(r=>r.orderId===o.id);
    regs.forEach(r=>{
      const pr=prod?.processes?.find(p=>p.id===r.processId);
      if(!pr)return;
      const key=pr.name.toLowerCase().trim(); // agrupar por nombre
      if(!dayProcSum[key])dayProcSum[key]={name:pr.name,totalMins:0,totalExpected:0};
      dayProcSum[key].totalMins+=r.minutes;
      if(o.qtyActual)dayProcSum[key].totalExpected+=Math.round(o.qtyActual*pr.timeTarget);
    });
  });

  // ── Resumen materias primas del día ──────────────────────────────────────
  const dayMatSum={};
  closed.forEach(o=>{
    (o.materialResults||[]).forEach(m=>{
      const key=m.name;
      if(!dayMatSum[key])dayMatSum[key]={name:m.name,unit:m.unit,expected:0,actual:0,yields:[]};
      dayMatSum[key].expected+=m.expected||0;
      dayMatSum[key].actual+=m.actual||0;
      if(m.yieldPct!=null)dayMatSum[key].yields.push(m.yieldPct);
    });
  });
  const dayMatRows=Object.values(dayMatSum).map(m=>({
    ...m,
    expected:+m.expected.toFixed(3),
    actual:+m.actual.toFixed(3),
    waste:+(m.actual-m.expected).toFixed(3),
    avgYield:m.yields.length?+(m.yields.reduce((a,b)=>a+b,0)/m.yields.length).toFixed(1):null,
  }));

  // ── Resumen jornada por operario ──────────────────────────────────────────
  const dayOpSum={};
  todayRegs.forEach(r=>{
    if(!dayOpSum[r.operatorName])dayOpSum[r.operatorName]={name:r.operatorName,totalMins:0};
    dayOpSum[r.operatorName].totalMins+=r.minutes;
  });
  const opJornada=Object.values(dayOpSum).map(e=>{
    const user=users.find(u=>u.name===e.name);
    const objMins=(user?.hoursPerDay||8)*60;
    return{...e,objMins,diff:e.totalMins-objMins};
  }).sort((a,b)=>b.totalMins-a.totalMins);

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:40}}>
      <Header title="RESULTADOS DEL DÍA" onBack={onBack} sub={fmtD(today())}/>
      <div style={{padding:14}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
          {[{v:closed.length,l:"Lotes cerrados",c:C.green},{v:avgYield?`${avgYield}%`:"—",l:"Rend. medio",c:(()=>{if(!avgYield)return C.muted;const t=closed.length?closed.reduce((a,o)=>a+(o.yieldTarget||100),0)/closed.length:100;return parseFloat(avgYield)>=t?C.green:C.red;})()},{v:allOps.size,l:"Operarios",c:C.blue}].map(k=>(
            <Card key={k.l} style={{padding:"12px 8px",textAlign:"center"}}>
              <div style={{fontFamily:F.h,fontWeight:800,fontSize:28,color:k.c}}>{k.v}</div>
              <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:0.4,marginTop:2}}>{k.l}</div>
            </Card>
          ))}
        </div>
        {open.length>0&&<div style={{background:"#fffbf5",border:`1px solid ${C.accent}`,borderRadius:12,padding:14,marginBottom:14}}><div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.accent}}>⚠️ {open.length} orden(es) sin cerrar</div>{open.map(o=>{const p=products.find(x=>x.id===o.productId);return <div key={o.id} style={{fontSize:13,color:C.muted,marginTop:4}}>• {p?.name}{o.equipment?` · ${o.equipment}`:""}</div>;})}</div>}
        {todayOrders.length===0&&<div style={{textAlign:"center",padding:"50px 20px",color:C.muted}}><div style={{fontSize:52,marginBottom:12}}>🏁</div><p style={{fontFamily:F.h,fontSize:18}}>Sin producción registrada hoy</p></div>}

        {/* ── RESUMEN PROCESOS DEL DÍA ── */}
        {Object.values(dayProcSum).length>0&&(
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:12,letterSpacing:0.5,textTransform:"uppercase"}}>⏱️ Procesos del día vs Objetivo</div>
            {Object.values(dayProcSum).map(p=>{
              const diff=p.totalExpected>0?p.totalMins-p.totalExpected:null;
              const pct=p.totalExpected>0?Math.round(p.totalMins/p.totalExpected*100):null;
              return(
                <div key={p.name} style={{padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:3}}>
                    <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{p.name}</span>
                    <span style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:C.text}}>{p.totalMins} min</span>
                  </div>
                  {diff!==null&&(
                    <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"center"}}>
                      <span style={{fontSize:12,color:C.muted}}>Obj: {p.totalExpected} min</span>
                      <span style={{fontSize:13,fontWeight:700,color:diff<=0?C.green:C.red}}>{diff>0?"+":""}{diff} min</span>
                      <span style={{fontSize:12,color:diff<=0?C.green:C.red}}>({pct}%) {diff<=0?"✓":"⚠"}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </Card>
        )}

        {/* ── MATERIAS PRIMAS DEL DÍA ── */}
        {dayMatRows.length>0&&(
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:12,letterSpacing:0.5,textTransform:"uppercase"}}>📦 Materias primas vs Objetivo</div>
            {dayMatRows.map(m=>(
              <div key={m.name} style={{padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{m.name}</span>
                  {m.avgYield!=null&&(
                    <span style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:m.avgYield>=90?C.green:m.avgYield>=75?C.yellow:C.red}}>{m.avgYield}%</span>
                  )}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6}}>
                  <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"7px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{m.expected} <span style={{fontSize:11,color:C.muted}}>{m.unit}</span></div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Esperado</div>
                  </div>
                  <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"7px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{m.actual} <span style={{fontSize:11,color:C.muted}}>{m.unit}</span></div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>Consumido</div>
                  </div>
                  <div style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"7px 4px"}}>
                    <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:m.waste>0?C.red:C.green}}>{m.waste>0?"+":""}{m.waste} <span style={{fontSize:11,color:C.muted}}>{m.unit}</span></div>
                    <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>{m.waste>0?"Exceso":"Ahorro"}</div>
                  </div>
                </div>
              </div>
            ))}
          </Card>
        )}

        {/* ── JORNADA POR OPERARIO ── */}
        {opJornada.length>0&&(
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:12,letterSpacing:0.5,textTransform:"uppercase"}}>👷 Jornada por operario</div>
            {opJornada.map(e=>{
              const realH=(e.totalMins/60).toFixed(1);
              const objH=(e.objMins/60).toFixed(1);
              const diffH=(e.diff/60).toFixed(1);
              const pct=Math.min(Math.round(e.totalMins/e.objMins*100),100);
              const color=e.diff>=0?C.green:C.red;
              return(
                <div key={e.name} style={{padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                    <div>
                      <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{e.name}</div>
                      <div style={{fontSize:12,color:C.muted}}>Jornada: {objH}h</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{realH}h</div>
                      <div style={{fontSize:13,fontWeight:700,color}}>{e.diff>=0?"+":""}{diffH}h {e.diff>=0?"✓":"▼"}</div>
                    </div>
                  </div>
                  <div style={{height:6,background:C.border,borderRadius:3,overflow:"hidden"}}>
                    <div style={{height:"100%",width:`${pct}%`,background:color,borderRadius:3}}/>
                  </div>
                  <div style={{fontSize:11,color:C.muted,marginTop:3,textAlign:"right"}}>{pct}% de la jornada</div>
                </div>
              );
            })}
          </Card>
        )}

        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {closed.map(o=>{
            const prod=products.find(p=>p.id===o.productId);
            const regs=registers.filter(r=>r.orderId===o.id);
            const ops=[...new Set(regs.map(r=>r.operatorName))];
            const yDiff=(o.yieldActual-o.yieldTarget).toFixed(1);
            const procSum={};
            regs.forEach(r=>{const pr=prod?.processes?.find(p=>p.id===r.processId);if(!pr)return;const k=pr.name.toLowerCase().trim();if(!procSum[k])procSum[k]={name:pr.name,targetPerUnit:pr.timeTarget,total:0};procSum[k].total+=r.minutes;});
            return(
              <Card key={o.id} color={parseFloat(yDiff)>=0?C.green:C.red}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                  <div><div style={{fontFamily:F.h,fontWeight:800,fontSize:21,color:C.text}}>{prod?.name||"—"}</div>{o.equipment&&<div style={{fontSize:13,color:C.blue,marginTop:2}}>🔧 {o.equipment}</div>}</div>
                  <div style={{textAlign:"right"}}><div style={{fontFamily:F.h,fontWeight:800,fontSize:28,color:parseFloat(yDiff)>=0?C.green:C.red}}>{o.yieldActual.toFixed(1)}%</div><div style={{fontSize:13,color:parseFloat(yDiff)>=0?C.green:C.red,fontWeight:700}}>{parseFloat(yDiff)>=0?"+":""}{yDiff}% vs obj ({o.yieldTarget}%)</div></div>
                </div>
                {/* Materias primas con unidades reales */}
                {o.materialResults?.length>0&&(
                  <div style={{marginBottom:12}}>
                    {o.materialResults.map(m=>(
                      <div key={m.id} style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:6,marginBottom:8}}>
                        <div style={{gridColumn:"1/-1",fontFamily:F.h,fontWeight:600,fontSize:14,color:C.text,marginBottom:2}}>{m.name}</div>
                        {[{l:"Esperado",v:`${m.expected} ${m.unit}`},{l:"Consumido",v:`${m.actual} ${m.unit}`},{l:m.waste>0?"Exceso":"Ahorro",v:`${m.waste>0?"+":""}${m.waste} ${m.unit}`,c:m.waste>0?C.red:C.green}].map(x=>(
                          <div key={x.l} style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"7px 4px"}}>
                            <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:x.c||C.text}}>{x.v}</div>
                            <div style={{fontSize:10,color:C.muted,textTransform:"uppercase"}}>{x.l}</div>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
                  {[{l:"Planificadas",v:`${o.qty} ${prod?.unit||""}`},{l:"Producidas",v:`${o.qtyActual||"—"} ${prod?.unit||""}`}].map(m=>(
                    <div key={m.l} style={{textAlign:"center",background:C.card2,borderRadius:8,padding:"8px 4px"}}><div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{m.v}</div><div style={{fontSize:11,color:C.muted,textTransform:"uppercase"}}>{m.l}</div></div>
                  ))}
                </div>
                {ops.length>0&&<div style={{marginBottom:10,display:"flex",flexWrap:"wrap",gap:5}}>{ops.map(op=><span key={op} style={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:20,padding:"3px 10px",fontSize:12,color:C.text}}>{op}</span>)}</div>}
                {Object.values(procSum).length>0&&(
                  <div style={{borderTop:`1px solid ${C.border}`,paddingTop:10}}>
                    <div style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:6,textTransform:"uppercase",letterSpacing:0.5}}>Tiempos vs Objetivo</div>
                    {Object.values(procSum).map(ps=>{
                      const expected=o.qtyActual?Math.round(o.qtyActual*ps.targetPerUnit):null;
                      const d=expected!=null?ps.total-expected:null;
                      const pct=expected&&expected>0?Math.round((ps.total/expected)*100):null;
                      return(
                        <div key={ps.name} style={{padding:"8px 0",borderBottom:`1px solid ${C.border}`}}>
                          <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                            <span style={{fontSize:14,color:C.text,fontFamily:F.h,fontWeight:600}}>{ps.name}</span>
                            <span style={{fontFamily:F.h,fontWeight:800,fontSize:16,color:C.text}}>{ps.total} min</span>
                          </div>
                          {expected!=null&&(
                            <div style={{display:"flex",gap:6}}>
                              <span style={{fontSize:12,color:C.muted}}>Obj: {expected} min</span>
                              <span style={{fontSize:12,fontWeight:700,color:d<=0?C.green:C.red}}>{d>0?"+":""}{d} min</span>
                              <span style={{fontSize:12,color:d<=0?C.green:C.red}}>({pct}%)</span>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── ESTADÍSTICAS ───────────────────────────────────────────────────────────────
function StatsScreen({onBack,products,orders,registers,users=[]}){
  const [period,setPeriod]=useState("mes");
  const [tab,setTab]=useState("general");
  const [pf,setPf]=useState("all");
  const [customFrom,setCustomFrom]=useState(()=>{const d=new Date();d.setDate(1);return d.toISOString().slice(0,10);});
  const [customTo,setCustomTo]=useState(today);

  const getRange=()=>{
    if(period==="fechas"&&customFrom&&customTo&&customFrom<=customTo)return[customFrom,customTo];
    const now=new Date();
    if(period==="semana"){const s=new Date(now);s.setDate(s.getDate()-6);return[s.toISOString().slice(0,10),today()];}
    if(period==="mes")return[new Date(now.getFullYear(),now.getMonth(),1).toISOString().slice(0,10),today()];
    if(period==="fechas")return[new Date(now.getFullYear(),now.getMonth(),1).toISOString().slice(0,10),today()];
    return[new Date(now.getFullYear(),0,1).toISOString().slice(0,10),today()];
  };
  const [s,e]=getRange();
  const fOrders=orders.filter(o=>o.date>=s&&o.date<=e&&o.status==="closed"&&(pf==="all"||o.productId===pf));
  const fRegs=registers.filter(r=>r.date>=s&&r.date<=e&&(pf==="all"||r.productId===pf));

  // ── Datos generales ──────────────────────────────────────────────────────────
  const avgYield=fOrders.length?(fOrders.reduce((a,b)=>a+b.yieldActual,0)/fOrders.length).toFixed(1):null;
  const totalOps=new Set(fRegs.map(r=>r.operatorName)).size;
  const totalQtyProduced=fOrders.reduce((a,o)=>a+(o.qtyActual||0),0);
  const totalQtyPlanned=fOrders.reduce((a,o)=>a+(o.qty||0),0);
  const completionRate=totalQtyPlanned>0?Math.round(totalQtyProduced/totalQtyPlanned*100):null;

  const yieldData=fOrders.map(o=>{
    const pr=products.find(x=>x.id===o.productId);
    const real=parseFloat(o.yieldActual?.toFixed(1)||0);
    const target=o.yieldTarget||100;
    return{date:fmtD(o.date),Real:real,Objetivo:target,ok:real>=target,name:pr?.name||""};
  });

  // ── Datos operarios por proceso ──────────────────────────────────────────────
  const opByProc={};
  fRegs.forEach(r=>{
    const prod=products.find(p=>p.id===r.productId);
    const pr=prod?.processes?.find(p=>p.id===r.processId);
    if(!pr||!r.qtyDone)return;
    if(!opByProc[pr.name])opByProc[pr.name]={target:pr.timeTarget,ops:{}};
    if(!opByProc[pr.name].ops[r.operatorName])opByProc[pr.name].ops[r.operatorName]={totalMins:0,totalQty:0,sessions:0};
    opByProc[pr.name].ops[r.operatorName].totalMins+=r.minutes;
    opByProc[pr.name].ops[r.operatorName].totalQty+=r.qtyDone;
    opByProc[pr.name].ops[r.operatorName].sessions+=1;
  });

  // ── Resumen de jornadas por empleado ─────────────────────────────────────────
  // Agrupa total minutos por operario + días trabajados
  const empJornada={};
  fRegs.forEach(r=>{
    const op=r.operatorName;
    if(!empJornada[op])empJornada[op]={name:op,totalMins:0,days:new Set()};
    empJornada[op].totalMins+=r.minutes;
    empJornada[op].days.add(r.date);
  });
  // Cruzar con configuración de horas/día del usuario
  const empRows=Object.values(empJornada).map(e=>{
    const user=users?.find(u=>u.name===e.name);
    const hoursPerDay=user?.hoursPerDay||8;
    const objMins=hoursPerDay*60*e.days.size;
    const diff=e.totalMins-objMins;
    return{...e,days:e.days.size,hoursPerDay,objMins,diff};
  }).sort((a,b)=>b.totalMins-a.totalMins);

  // ── Datos procesos ───────────────────────────────────────────────────────────
  const procStats={};
  fRegs.forEach(r=>{
    const prod=products.find(p=>p.id===r.productId);
    const pr=prod?.processes?.find(p=>p.id===r.processId);
    if(!pr)return;
    const pk=pr.name.toLowerCase().trim();
    if(!procStats[pk])procStats[pk]={name:pr.name,target:pr.timeTarget,totalMins:0,totalQty:0,delays:0,sessions:0};
    procStats[pk].totalMins+=r.minutes;
    procStats[pk].totalQty+=(r.qtyDone||0);
    procStats[pk].sessions+=1;
    if(r.qtyDone){const exp=r.qtyDone*pr.timeTarget;if(r.minutes>exp)procStats[pk].delays+=1;}
  });

  // ── Datos materias primas por proveedor ──────────────────────────────────────
  const supplierStats={};
  fOrders.forEach(o=>{
    if(!o.materialResults)return;
    o.materialResults.forEach(m=>{
      const sup=m.supplier||"Sin proveedor";
      const key=`${m.name}__${sup}`;
      if(!supplierStats[key])supplierStats[key]={mat:m.name,sup,yields:[],count:0,targets:[]};
      if(m.yieldPct!=null){supplierStats[key].yields.push(m.yieldPct);supplierStats[key].count++;}
      if(o.yieldTarget!=null)supplierStats[key].targets.push(o.yieldTarget);
    });
  });
  const supplierData=Object.values(supplierStats).map(s=>({
    ...s,
    avgYield:s.yields.length?+(s.yields.reduce((a,b)=>a+b,0)/s.yields.length).toFixed(1):null,
    avgTarget:s.targets.length?+(s.targets.reduce((a,b)=>a+b,0)/s.targets.length).toFixed(1):100,
  }));

  // ── Datos de costes por artículo ─────────────────────────────────────────
  const costByProduct={};
  fOrders.forEach(o=>{
    const prod=products.find(p=>p.id===o.productId);
    if(!prod)return;
    const name=prod.name;
    if(!costByProduct[name])costByProduct[name]={name,suppliers:{},employees:{},matReal:0,matObj:0,moReal:0,moObj:0};
    const regsO=registers.filter(r=>r.orderId===o.id);
    // Materiales por proveedor
    (o.materialResults||[]).forEach(m=>{
      const matDef=prod.materials?.find(x=>x.name===m.name);
      const price=matDef?.pricePerUnit||0;
      const sup=m.supplier||matDef?.supplier||"Sin proveedor";
      const key=`${m.name} · ${sup}`;
      if(!costByProduct[name].suppliers[key])costByProduct[name].suppliers[key]={label:key,real:0,obj:0};
      costByProduct[name].suppliers[key].real+=(m.actual||0)*price;
      costByProduct[name].suppliers[key].obj+=(m.expected||0)*price;
      costByProduct[name].matReal+=(m.actual||0)*price;
      costByProduct[name].matObj+=(m.expected||0)*price;
    });
    // Mano de obra por empleado
    regsO.forEach(r=>{
      const u=users?.find(x=>x.name===r.operatorName);
      const rate=(u?.costPerHour||0)/60;
      const cost=r.minutes*rate;
      if(!costByProduct[name].employees[r.operatorName])costByProduct[name].employees[r.operatorName]={label:r.operatorName,real:0,obj:0};
      costByProduct[name].employees[r.operatorName].real+=cost;
      costByProduct[name].moReal+=cost;
    });
    // Objetivo MO
    const avgRate=(users||[]).filter(u=>u.role==="operator"&&u.costPerHour>0).reduce((a,u,_,arr)=>a+u.costPerHour/arr.length,0)/60;
    if(o.qtyActual){
      prod.processes?.forEach(pr=>{
        if(!pr.deferred){
          const objCost=o.qtyActual*pr.timeTarget*avgRate;
          costByProduct[name].moObj+=objCost;
          // distribute obj MO proportionally to employees
          const empKeys=Object.keys(costByProduct[name].employees);
          if(empKeys.length>0){
            const share=objCost/empKeys.length;
            empKeys.forEach(k=>{costByProduct[name].employees[k].obj+=share;});
          }
        }
      });
    }
  });
  const costProducts=Object.values(costByProduct).map(p=>({
    ...p,
    totalReal:p.matReal+p.moReal,
    totalObj:p.matObj+p.moObj,
    diff:(p.matReal+p.moReal)-(p.matObj+p.moObj),
  }));
  const grandReal=costProducts.reduce((a,p)=>a+p.totalReal,0);
  const grandObj=costProducts.reduce((a,p)=>a+p.totalObj,0);
  const grandDiff=grandReal-grandObj;

  const tabs=[
    {id:"general",icon:"📈",label:"General"},
    {id:"operarios",icon:"👷",label:"Operarios"},
    {id:"procesos",icon:"⏱️",label:"Procesos"},
    {id:"materiales",icon:"📦",label:"Materiales"},
    {id:"tendencias",icon:"🎯",label:"Objetivos"},
    {id:"costes",icon:"💰",label:"Costes"},
  ];

  const empty=fOrders.length===0&&fRegs.length===0;
  const KPI=({v,l,c})=>(
    <Card style={{padding:"12px 8px",textAlign:"center"}}>
      <div style={{fontFamily:F.h,fontWeight:800,fontSize:26,color:c||C.accent}}>{v}</div>
      <div style={{fontSize:10,color:C.muted,textTransform:"uppercase",letterSpacing:0.4,marginTop:2}}>{l}</div>
    </Card>
  );
  const SecTitle=({t})=><div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:10,letterSpacing:0.5,textTransform:"uppercase"}}>{t}</div>;

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:40}}>
      <Header title="ESTADÍSTICAS" onBack={onBack}/>
      <div style={{padding:"12px 14px 0"}}>
        {/* Period */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:6,marginBottom:8}}>
          {["semana","mes","año","fechas"].map(p=>(
            <button key={p} onClick={()=>setPeriod(p)}
              style={{padding:"10px 4px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:14,cursor:"pointer",border:`1.5px solid ${period===p?C.accent:C.border}`,background:"#fff",color:period===p?C.accent:C.muted,textTransform:"uppercase"}}>
              {p}
            </button>
          ))}
        </div>
        {period==="fechas"&&(
          <div style={{marginBottom:8}}>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              <div>
                <label style={{display:"block",fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:4,textTransform:"uppercase",letterSpacing:0.5}}>Desde</label>
                <input type="date" value={customFrom} onChange={e=>setCustomFrom(e.target.value)}
                  style={{width:"100%",background:"#fff",border:`1.5px solid ${customFrom?C.accent:C.border}`,color:C.text,borderRadius:12,padding:"14px 12px",fontFamily:F.b,fontSize:16,outline:"none",boxSizing:"border-box",WebkitAppearance:"none"}}/>
              </div>
              <div>
                <label style={{display:"block",fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,marginBottom:4,textTransform:"uppercase",letterSpacing:0.5}}>Hasta</label>
                <input type="date" value={customTo} onChange={e=>setCustomTo(e.target.value)}
                  style={{width:"100%",background:"#fff",border:`1.5px solid ${customTo?C.accent:C.border}`,color:C.text,borderRadius:12,padding:"14px 12px",fontFamily:F.b,fontSize:16,outline:"none",boxSizing:"border-box",WebkitAppearance:"none"}}/>
              </div>
            </div>
            {customFrom&&customTo&&customFrom>customTo&&(
              <div style={{marginTop:6,fontSize:13,color:C.red,fontFamily:F.h,fontWeight:600}}>⚠️ La fecha "Desde" debe ser anterior a "Hasta"</div>
            )}
            {customFrom&&customTo&&customFrom<=customTo&&(
              <div style={{marginTop:6,padding:"8px 12px",background:C.greenBg,borderRadius:8,fontSize:13,color:C.green,fontFamily:F.h,fontWeight:600}}>
                ✓ Del {fmtD(customFrom)} al {fmtD(customTo)}
              </div>
            )}
          </div>
        )}
        <Sel value={pf} onChange={setPf} options={[{value:"all",label:"Todos los artículos"},...products.map(p=>({value:p.id,label:p.name}))]}/>
        {/* Tabs */}
        <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:4,marginBottom:12}}>
          {tabs.map(t=><button key={t.id} onClick={()=>setTab(t.id)} style={{flexShrink:0,padding:"8px 12px",borderRadius:10,fontFamily:F.h,fontWeight:700,fontSize:14,cursor:"pointer",border:`1.5px solid ${tab===t.id?C.accent:C.border}`,background:"#fff",color:tab===t.id?C.accent:C.muted,whiteSpace:"nowrap"}}>{t.icon} {t.label}</button>)}
        </div>
      </div>

      <div style={{padding:"0 14px 14px"}}>
        {empty&&<div style={{textAlign:"center",padding:"50px 20px",color:C.muted}}><div style={{fontSize:52,marginBottom:12}}>📊</div><p style={{fontFamily:F.h,fontSize:18}}>Sin datos en este período</p></div>}

        {/* ── GENERAL ── */}
        {!empty&&tab==="general"&&(
          <>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
              <KPI v={fOrders.length} l="Lotes" c={C.accent}/>
              <KPI v={avgYield?`${avgYield}%`:"—"} l="Rend. medio" c={(()=>{
                if(!avgYield)return C.muted;
                const avgTarget=fOrders.length?fOrders.reduce((a,o)=>a+(o.yieldTarget||100),0)/fOrders.length:100;
                return parseFloat(avgYield)>=avgTarget?C.green:C.red;
              })()}/>
              <KPI v={totalOps} l="Operarios" c={C.blue}/>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
              <KPI v={totalQtyProduced} l="Uds. producidas" c={C.text}/>
              <KPI v={completionRate!=null?`${completionRate}%`:"—"} l="Cumplimiento plan" c={completionRate>=100?C.green:completionRate>=80?C.yellow:C.red}/>
            </div>
            {yieldData.length>0&&<Card style={{marginBottom:14}}>
              <SecTitle t="Rendimiento vs Objetivo (%)"/>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={yieldData} margin={{top:0,right:0,left:-20,bottom:0}}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
                  <XAxis dataKey="date" tick={{fontSize:11,fill:C.muted}}/>
                  <YAxis tick={{fontSize:11,fill:C.muted}} domain={[0,100]}/>
                  <Tooltip contentStyle={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:8,color:C.text}}/>
                  <Legend wrapperStyle={{fontSize:12}}/>
                  <Bar dataKey="Real" fill={C.accent} radius={[4,4,0,0]}/>
                  <Bar dataKey="Objetivo" fill="#22c55e88" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </Card>}
            {fOrders.length>0&&<Card>
              <SecTitle t="Historial de lotes"/>
              {[...fOrders].reverse().map(o=>{
                const p=products.find(x=>x.id===o.productId);
                const d=(o.yieldActual-o.yieldTarget).toFixed(1);
                return(<div key={o.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                  <div><div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{p?.name||"—"}</div><div style={{fontSize:12,color:C.muted}}>{fmtD(o.date)}{o.equipment?` · ${o.equipment}`:""} · {o.qtyActual||"—"}/{o.qty} {p?.unit||""}</div></div>
                  <div style={{textAlign:"right"}}><div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:parseFloat(d)>=0?C.green:C.red}}>{o.yieldActual?.toFixed(1)}%</div><div style={{fontSize:12,color:parseFloat(d)>=0?C.green:C.red,fontWeight:700}}>{parseFloat(d)>=0?"+":""}{d}%</div></div>
                </div>);
              })}
            </Card>}
          </>
        )}

        {/* ── OPERARIOS ── */}
        {!empty&&tab==="operarios"&&(
          <>
            {/* Resumen de jornadas */}
            {empRows.length>0&&(
              <Card style={{marginBottom:14}}>
                <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:4,letterSpacing:0.5,textTransform:"uppercase"}}>⏱️ Horas trabajadas vs jornada</div>
                <div style={{fontSize:12,color:C.muted,marginBottom:12}}>{e.days>1?`${e.days} días trabajados en el período`:""}</div>
                {empRows.map(e=>{
                  const realH=(e.totalMins/60).toFixed(1);
                  const objH=(e.objMins/60).toFixed(1);
                  const diffH=(e.diff/60).toFixed(1);
                  const pct=e.objMins>0?Math.round(e.totalMins/e.objMins*100):100;
                  const color=e.diff>0?C.green:e.diff<0?C.red:C.green;
                  return(
                    <div key={e.name} style={{padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                        <div>
                          <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{e.name}</div>
                          <div style={{fontSize:12,color:C.muted}}>{e.days} día(s) · {e.hoursPerDay}h/día · obj: {objH}h</div>
                        </div>
                        <div style={{textAlign:"right"}}>
                          <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:C.text}}>{realH}h</div>
                          <div style={{fontSize:13,fontWeight:700,color}}>{e.diff>0?"+":""}{diffH}h {e.diff===0?"✓":e.diff>0?"▲":"▼"}</div>
                        </div>
                      </div>
                      {/* Barra de progreso */}
                      <div style={{height:6,background:C.border,borderRadius:3,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:color,borderRadius:3}}/>
                      </div>
                      <div style={{fontSize:11,color:C.muted,marginTop:3,textAlign:"right"}}>{pct}% de la jornada</div>
                    </div>
                  );
                })}
              </Card>
            )}
            {Object.keys(opByProc).length===0&&empRows.length===0&&<div style={{textAlign:"center",padding:"30px 20px",color:C.muted,fontFamily:F.h,fontSize:16}}>Sin registros en este período</div>}
            {Object.keys(opByProc).length>0&&<div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.muted,marginBottom:10,textTransform:"uppercase",letterSpacing:0.5}}>Rendimiento por proceso</div>}
            {Object.entries(opByProc).map(([procName,{target,ops}])=>{
              const rows=Object.entries(ops).map(([op,d])=>({
                op,
                minPerUnit:d.totalQty>0?+(d.totalMins/d.totalQty).toFixed(2):null,
                totalQty:d.totalQty,
                sessions:d.sessions,
              })).filter(r=>r.minPerUnit!=null).sort((a,b)=>a.minPerUnit-b.minPerUnit);
              if(!rows.length)return null;
              return(
                <Card key={procName} style={{marginBottom:14}}>
                  <SecTitle t={`${procName} — obj: ${target} min/ud`}/>
                  {rows.map((r,i)=>{
                    const diff=+(r.minPerUnit-target).toFixed(2);
                    const isFirst=i===0; const isLast=i===rows.length-1&&rows.length>1;
                    return(
                      <div key={r.op} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                        <div style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:isFirst?C.green:isLast?C.red:C.muted,minWidth:24}}>#{i+1}</div>
                        <div style={{flex:1}}>
                          <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{r.op}</div>
                          <div style={{fontSize:12,color:C.muted}}>{r.totalQty} uds · {r.sessions} sesiones</div>
                        </div>
                        <div style={{textAlign:"right"}}>
                          <div style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:C.text}}>{r.minPerUnit} min/ud</div>
                          <div style={{fontSize:12,fontWeight:700,color:diff<=0?C.green:C.red}}>{diff>0?"+":""}{diff} vs obj</div>
                        </div>
                      </div>
                    );
                  })}
                  {rows.length>=2&&(
                    <div style={{marginTop:10,padding:"8px 12px",background:C.card2,borderRadius:8,fontSize:13,color:C.muted}}>
                      Diferencia entre mejor y peor: <span style={{color:C.yellow,fontWeight:700}}>{+(rows[rows.length-1].minPerUnit-rows[0].minPerUnit).toFixed(2)} min/ud</span>
                    </div>
                  )}
                </Card>
              );
            })}
          </>
        )}

        {/* ── PROCESOS ── */}
        {!empty&&tab==="procesos"&&(
          <>
            {Object.values(procStats).length===0&&<div style={{textAlign:"center",padding:"30px 20px",color:C.muted,fontFamily:F.h,fontSize:16}}>Sin datos de procesos</div>}
            {/* Procesos con más retrasos */}
            {Object.values(procStats).filter(p=>p.sessions>0).sort((a,b)=>(b.delays/b.sessions)-(a.delays/a.sessions)).map(p=>{
              const avgMpU=p.totalQty>0?+(p.totalMins/p.totalQty).toFixed(2):null;
              const delayRate=Math.round(p.delays/p.sessions*100);
              const diff=avgMpU!=null?+(avgMpU-p.target).toFixed(2):null;
              return(
                <Card key={p.name} style={{marginBottom:10,borderColor:delayRate>50?`${C.red}66`:delayRate>25?`${C.yellow}66`:`${C.green}66`}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                    <div>
                      <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{p.name}</div>
                      <div style={{fontSize:12,color:C.muted}}>Obj: {p.target} min/ud · {p.sessions} sesiones · {p.totalQty} uds</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:22,color:delayRate>50?C.red:delayRate>25?C.yellow:C.green}}>{delayRate}%</div>
                      <div style={{fontSize:11,color:C.muted}}>retrasos</div>
                    </div>
                  </div>
                  {avgMpU&&<div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                    <span style={{fontSize:13,color:C.muted}}>Media: <span style={{color:C.text,fontWeight:700}}>{avgMpU} min/ud</span></span>
                    {diff!=null&&<span style={{fontSize:13,fontWeight:700,color:diff<=0?C.green:C.red}}>{diff>0?"+":""}{diff} min/ud vs obj</span>}
                  </div>}
                </Card>
              );
            })}
            {/* Barras de tiempo medio vs objetivo */}
            {Object.values(procStats).length>0&&(()=>{
              const chartData=Object.values(procStats).filter(p=>p.totalQty>0).map(p=>({
                proceso:p.name.length>10?p.name.slice(0,10)+"…":p.name,
                "Real":+(p.totalMins/p.totalQty).toFixed(1),
                "Objetivo":p.target,
              }));
              return chartData.length>0&&(
                <Card style={{marginTop:14}}>
                  <SecTitle t="Min / unidad por proceso"/>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={chartData} margin={{top:0,right:0,left:-20,bottom:0}}>
                      <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
                      <XAxis dataKey="proceso" tick={{fontSize:11,fill:C.muted}}/>
                      <YAxis tick={{fontSize:11,fill:C.muted}}/>
                      <Tooltip contentStyle={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:8,color:C.text}}/>
                      <Legend wrapperStyle={{fontSize:12}}/>
                      <Bar dataKey="Real" fill={C.accent} radius={[4,4,0,0]}/>
                      <Bar dataKey="Objetivo" fill={C.green} radius={[4,4,0,0]}/>
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              );
            })()}
          </>
        )}

        {/* ── MATERIALES / PROVEEDORES ── */}
        {!empty&&tab==="materiales"&&(
          <>
            {supplierData.length===0&&<div style={{textAlign:"center",padding:"30px 20px",color:C.muted,fontFamily:F.h,fontSize:16}}>Sin datos de materiales. Configura proveedores en los artículos.</div>}
            {/* Agrupar por materia prima */}
            {(()=>{
              const byMat={};
              supplierData.forEach(s=>{if(!byMat[s.mat])byMat[s.mat]=[];byMat[s.mat].push(s);});
              return Object.entries(byMat).map(([mat,sups])=>(
                <Card key={mat} style={{marginBottom:14}}>
                  <SecTitle t={mat}/>
                  {sups.sort((a,b)=>(b.avgYield||0)-(a.avgYield||0)).map((s,i)=>(
                    <div key={s.sup} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:i===0?C.green:C.muted,minWidth:24}}>#{i+1}</div>
                      <div style={{flex:1}}>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{s.sup}</div>
                        <div style={{fontSize:12,color:C.muted}}>{s.count} lotes</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:F.h,fontWeight:800,fontSize:20,color:s.avgYield==null?C.muted:s.avgYield>=s.avgTarget?C.green:C.red}}>{s.avgYield!=null?`${s.avgYield}%`:"—"}</div>
                        <div style={{fontSize:11,color:C.muted}}>obj: {s.avgTarget}% · {s.count} lotes</div>
                      </div>
                    </div>
                  ))}
                </Card>
              ));
            })()}
            {/* Tabla consumo acumulado por material */}
            {fOrders.length>0&&(()=>{
              const matTotals={};
              fOrders.forEach(o=>{
                (o.materialResults||[]).forEach(m=>{
                  const k=m.name;
                  if(!matTotals[k])matTotals[k]={name:k,unit:m.unit,expected:0,actual:0};
                  matTotals[k].expected+=m.expected||0;
                  matTotals[k].actual+=m.actual||0;
                });
              });
              const rows=Object.values(matTotals);
              if(!rows.length)return null;
              return(
                <Card>
                  <SecTitle t="Consumo total del período"/>
                  {rows.map(m=>{
                    const waste=+(m.actual-m.expected).toFixed(2);
                    const yld=m.actual>0?+(m.expected/m.actual*100).toFixed(1):null;
                    return(
                      <div key={m.name} style={{padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                        <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                          <span style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{m.name}</span>
                          <span style={{fontFamily:F.h,fontWeight:800,fontSize:15,color:C.text}}>{m.actual} {m.unit}</span>
                        </div>
                        <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                          <span style={{fontSize:12,color:C.muted}}>Esperado: {m.expected.toFixed(2)} {m.unit}</span>
                          <span style={{fontSize:12,color:waste>0?C.red:C.green,fontWeight:700}}>{waste>0?"Exceso":"Ahorro"}: {Math.abs(waste)} {m.unit}</span>
                          {yld&&<span style={{fontSize:12,color:yld>=90?C.green:C.yellow}}>Rend: {yld}%</span>}
                        </div>
                      </div>
                    );
                  })}
                </Card>
              );
            })()}
          </>
        )}

        {/* ── COSTES ── */}
        {!empty&&tab==="costes"&&(
          <>
            {costProducts.length===0&&(
              <div style={{textAlign:"center",padding:"40px 20px",color:C.muted}}>
                <div style={{fontSize:48,marginBottom:12}}>💰</div>
                <p style={{fontFamily:F.h,fontSize:16}}>Sin datos de costes</p>
                <p style={{fontSize:13,marginTop:8}}>Configura precios en materias primas y coste/hora en operarios</p>
              </div>
            )}
            {costProducts.length>0&&(
              <>
                {/* ── RESUMEN TOTAL ── */}
                <div style={{background:grandDiff<=0?C.greenBg:C.redBg,border:`2px solid ${grandDiff<=0?C.green:C.red}`,borderRadius:16,padding:18,marginBottom:14}}>
                  <div style={{fontFamily:F.h,fontWeight:700,fontSize:13,color:C.muted,textTransform:"uppercase",letterSpacing:0.5,marginBottom:12}}>TOTAL DEL PERÍODO</div>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:12}}>
                    <div>
                      <div style={{fontFamily:F.h,fontWeight:900,fontSize:38,color:grandDiff<=0?C.green:C.red,lineHeight:1}}>{grandDiff<=0?"+":"-"}{Math.abs(grandDiff).toFixed(0)}€</div>
                      <div style={{fontSize:13,color:C.muted,marginTop:4}}>{grandDiff<=0?"Ahorro sobre objetivo":"Exceso sobre objetivo"}</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontSize:13,color:C.muted}}>Real: <span style={{fontFamily:F.h,fontWeight:700,color:C.text,fontSize:16}}>{grandReal.toFixed(0)}€</span></div>
                      <div style={{fontSize:13,color:C.muted,marginTop:2}}>Obj: <span style={{fontFamily:F.h,fontWeight:700,color:C.muted,fontSize:16}}>{grandObj.toFixed(0)}€</span></div>
                    </div>
                  </div>
                  {/* Barra de progreso real vs objetivo */}
                  {grandObj>0&&(
                    <div>
                      <div style={{height:8,background:"rgba(0,0,0,0.08)",borderRadius:4,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${Math.min(grandReal/grandObj*100,100).toFixed(0)}%`,background:grandDiff<=0?C.green:C.red,borderRadius:4}}/>
                      </div>
                      <div style={{fontSize:11,color:C.muted,marginTop:4,textAlign:"right"}}>{(grandReal/grandObj*100).toFixed(0)}% del objetivo</div>
                    </div>
                  )}
                </div>

                {/* ── RESUMEN GLOBAL PROVEEDORES ── */}
                {(()=>{
                  const allSups={};
                  costProducts.forEach(p=>{
                    Object.values(p.suppliers).forEach(s=>{
                      const sup=s.label.split(' · ')[1]||s.label;
                      if(!allSups[sup])allSups[sup]={name:sup,real:0,obj:0};
                      allSups[sup].real+=s.real;
                      allSups[sup].obj+=s.obj;
                    });
                  });
                  const rows=Object.values(allSups).sort((a,b)=>Math.abs(a.real-a.obj)-Math.abs(b.real-b.obj));
                  if(!rows.length)return null;
                  return(
                    <Card style={{marginBottom:14}}>
                      <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:12,textTransform:"uppercase",letterSpacing:0.5}}>📦 Resumen por Proveedor</div>
                      {rows.map(s=>{
                        const d=s.real-s.obj;
                        return(
                          <div key={s.name} style={{marginBottom:12}}>
                            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                              <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{s.name}</span>
                              <div>
                                <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginRight:10}}>{s.real.toFixed(0)}€</span>
                                <span style={{fontFamily:F.h,fontWeight:800,fontSize:16,color:d<=0?C.green:C.red}}>{d<=0?"+":"-"}{Math.abs(d).toFixed(0)}€</span>
                              </div>
                            </div>
                            {s.obj>0&&<div style={{height:6,background:C.border,borderRadius:3,overflow:"hidden"}}>
                              <div style={{height:"100%",width:`${Math.min(s.real/s.obj*100,100)}%`,background:d<=0?C.green:C.red,borderRadius:3}}/>
                            </div>}
                          </div>
                        );
                      })}
                    </Card>
                  );
                })()}

                {/* ── RESUMEN GLOBAL EMPLEADOS ── */}
                {(()=>{
                  const allEmps={};
                  costProducts.forEach(p=>{
                    Object.values(p.employees).forEach(e=>{
                      if(!allEmps[e.label])allEmps[e.label]={name:e.label,real:0,obj:0};
                      allEmps[e.label].real+=e.real;
                      allEmps[e.label].obj+=e.obj;
                    });
                  });
                  const rows=Object.values(allEmps).sort((a,b)=>b.real-a.real);
                  if(!rows.length)return null;
                  return(
                    <Card style={{marginBottom:14}}>
                      <div style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text,marginBottom:12,textTransform:"uppercase",letterSpacing:0.5}}>👷 Resumen por Empleado</div>
                      {rows.map(e=>{
                        const d=e.real-e.obj;
                        return(
                          <div key={e.name} style={{marginBottom:12}}>
                            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                              <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text}}>{e.name}</span>
                              <div>
                                <span style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:C.text,marginRight:10}}>{e.real.toFixed(0)}€</span>
                                {e.obj>0&&<span style={{fontFamily:F.h,fontWeight:800,fontSize:16,color:d<=0?C.green:C.red}}>{d<=0?"+":"-"}{Math.abs(d).toFixed(0)}€</span>}
                              </div>
                            </div>
                            {e.obj>0&&<div style={{height:6,background:C.border,borderRadius:3,overflow:"hidden"}}>
                              <div style={{height:"100%",width:`${Math.min(e.real/e.obj*100,100)}%`,background:d<=0?C.green:C.red,borderRadius:3}}/>
                            </div>}
                          </div>
                        );
                      })}
                    </Card>
                  );
                })()}

                {/* ── POR ARTÍCULO ── */}
                {costProducts.map(p=>(
                  <Card key={p.name} style={{marginBottom:14}}>
                    {/* Cabecera artículo */}
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14,paddingBottom:12,borderBottom:`2px solid ${p.diff<=0?C.green:C.red}`}}>
                      <div style={{fontFamily:F.h,fontWeight:800,fontSize:19,color:C.text}}>{p.name}</div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:F.h,fontWeight:900,fontSize:22,color:p.diff<=0?C.green:C.red}}>{p.diff<=0?"+":"-"}{Math.abs(p.diff).toFixed(0)}€</div>
                        <div style={{fontSize:11,color:C.muted}}>{(p.totalReal/Math.max(p.totalObj,1)*100).toFixed(0)}% del objetivo</div>
                      </div>
                    </div>

                    {/* Mini KPIs materiales + MO */}
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
                      <div style={{background:C.card2,borderRadius:10,padding:"10px 12px"}}>
                        <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:0.3,marginBottom:4}}>📦 Materias</div>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{p.matReal.toFixed(0)}€</div>
                        <div style={{fontSize:11,color:p.matReal<=p.matObj?C.green:C.red,fontWeight:600}}>{(p.matReal-p.matObj)<=0?"+":"-"}{Math.abs(p.matReal-p.matObj).toFixed(0)}€ vs obj</div>
                      </div>
                      <div style={{background:C.card2,borderRadius:10,padding:"10px 12px"}}>
                        <div style={{fontSize:11,color:C.muted,textTransform:"uppercase",letterSpacing:0.3,marginBottom:4}}>👷 Mano de obra</div>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.text}}>{p.moReal.toFixed(0)}€</div>
                        <div style={{fontSize:11,color:p.moReal<=p.moObj?C.green:C.red,fontWeight:600}}>{(p.moReal-p.moObj)<=0?"+":"-"}{Math.abs(p.moReal-p.moObj).toFixed(0)}€ vs obj</div>
                      </div>
                    </div>

                    {/* Proveedores */}
                    {Object.keys(p.suppliers).length>0&&(
                      <div style={{marginBottom:12}}>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:12,color:C.muted,textTransform:"uppercase",letterSpacing:0.5,marginBottom:8}}>Por proveedor</div>
                        {Object.values(p.suppliers).map(s=>{
                          const d=s.real-s.obj;
                          const pct=s.obj>0?Math.min(s.real/s.obj*100,150):100;
                          return(
                            <div key={s.label} style={{marginBottom:10}}>
                              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                                <span style={{fontFamily:F.h,fontWeight:600,fontSize:14,color:C.text}}>{s.label}</span>
                                <div style={{textAlign:"right"}}>
                                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{s.real.toFixed(2)}€</span>
                                  <span style={{fontFamily:F.h,fontWeight:600,fontSize:12,color:d<=0?C.green:C.red,marginLeft:8}}>{d>0?"+":""}{d.toFixed(2)}€</span>
                                </div>
                              </div>
                              {s.obj>0&&<div style={{height:5,background:C.border,borderRadius:3,overflow:"hidden"}}>
                                <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:d<=0?C.green:C.red,borderRadius:3}}/>
                              </div>}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {/* Empleados */}
                    {Object.keys(p.employees).length>0&&(
                      <div>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:12,color:C.muted,textTransform:"uppercase",letterSpacing:0.5,marginBottom:8}}>Por empleado</div>
                        {Object.values(p.employees).map(e=>{
                          const d=e.real-e.obj;
                          const pct=e.obj>0?Math.min(e.real/e.obj*100,150):100;
                          return(
                            <div key={e.label} style={{marginBottom:10}}>
                              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                                <span style={{fontFamily:F.h,fontWeight:600,fontSize:14,color:C.text}}>{e.label}</span>
                                <div style={{textAlign:"right"}}>
                                  <span style={{fontFamily:F.h,fontWeight:700,fontSize:15,color:C.text}}>{e.real.toFixed(2)}€</span>
                                  {e.obj>0&&<span style={{fontFamily:F.h,fontWeight:600,fontSize:12,color:d<=0?C.green:C.red,marginLeft:8}}>{d<=0?"+":"-"}{Math.abs(d).toFixed(2)}€</span>}
                                </div>
                              </div>
                              {e.obj>0&&<div style={{height:5,background:C.border,borderRadius:3,overflow:"hidden"}}>
                                <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:d<=0?C.green:C.red,borderRadius:3}}/>
                              </div>}
                            </div>
                          );
                        })}
                      </div>
                    )}

                    {Object.keys(p.suppliers).length===0&&Object.keys(p.employees).length===0&&(
                      <div style={{fontSize:12,color:C.muted,fontStyle:"italic",textAlign:"center",padding:"8px 0"}}>
                        Configura precios en materias primas y coste/hora en operarios
                      </div>
                    )}
                  </Card>
                ))}
              </>
            )}
          </>
        )}

        {/* ── TENDENCIAS / OBJETIVOS ── */}
        {!empty&&tab==="tendencias"&&(
          <>
            {/* Cumplimiento de plan por lote */}
            <Card style={{marginBottom:14}}>
              <SecTitle t="Producción real vs planificada"/>
              {fOrders.length===0&&<p style={{color:C.muted,fontSize:14}}>Sin datos</p>}
              {fOrders.map(o=>{
                const prod=products.find(p=>p.id===o.productId);
                const pct=o.qty>0?Math.round((o.qtyActual||0)/o.qty*100):0;
                return(
                  <div key={o.id} style={{padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                      <div>
                        <div style={{fontFamily:F.h,fontWeight:700,fontSize:14,color:C.text}}>{prod?.name||"—"}</div>
                        <div style={{fontSize:11,color:C.muted}}>{fmtD(o.date)}</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:pct>=100?C.green:pct>=80?C.yellow:C.red}}>{pct}%</div>
                        <div style={{fontSize:11,color:C.muted}}>{o.qtyActual||0}/{o.qty} {prod?.unit||""}</div>
                      </div>
                    </div>
                    <div style={{height:6,background:C.border,borderRadius:3,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${Math.min(pct,100)}%`,background:pct>=100?C.green:pct>=80?C.yellow:C.red,borderRadius:3,transition:"width 0.3s"}}/>
                    </div>
                  </div>
                );
              })}
            </Card>
            {/* Evolución rendimiento */}
            {yieldData.length>1&&<Card style={{marginBottom:14}}>
              <SecTitle t="Evolución del rendimiento"/>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={yieldData} margin={{top:0,right:0,left:-20,bottom:0}}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
                  <XAxis dataKey="date" tick={{fontSize:10,fill:C.muted}}/>
                  <YAxis tick={{fontSize:10,fill:C.muted}} domain={[0,100]}/>
                  <Tooltip contentStyle={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:8,color:C.text}}/>
                  <Bar dataKey="Real" fill={C.accent} radius={[4,4,0,0]}/>
                  <Bar dataKey="Objetivo" fill="#22c55e55" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
              {yieldData.length>=2&&(()=>{
                const first=yieldData[0].Real; const last=yieldData[yieldData.length-1].Real;
                const trend=+(last-first).toFixed(1);
                return <div style={{marginTop:10,padding:"8px 12px",background:C.card2,borderRadius:8,fontSize:13,color:C.muted}}>
                  Tendencia: <span style={{color:trend>=0?C.green:C.red,fontWeight:700}}>{trend>=0?"▲":"▼"} {Math.abs(trend)}% {trend>=0?"mejora":"empeoramiento"}</span> en el período
                </div>;
              })()}
            </Card>}
            {/* Resumen global del período */}
            <Card>
              <SecTitle t="Resumen del período"/>
              {[
                {l:"Lotes completados",v:fOrders.length,c:C.accent},
                {l:"Rendimiento medio mat.",v:avgYield?`${avgYield}%`:"—",c:avgYield>=90?C.green:avgYield>=75?C.yellow:C.red},
                {l:"Uds. producidas",v:totalQtyProduced,c:C.text},
                {l:"Cumplimiento de plan",v:completionRate!=null?`${completionRate}%`:"—",c:completionRate>=100?C.green:completionRate>=80?C.yellow:C.red},
                {l:"Operarios activos",v:totalOps,c:C.blue},
              ].map(k=><div key={k.l} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:`1px solid ${C.border}`}}>
                <span style={{fontSize:14,color:C.muted}}>{k.l}</span>
                <span style={{fontFamily:F.h,fontWeight:800,fontSize:18,color:k.c}}>{k.v}</span>
              </div>)}
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

// ── CONFIGURACIÓN ──────────────────────────────────────────────────────────────
function ConfigScreen({onBack,onGo,products,onSave}){
  const del=id=>{if(window.confirm("¿Eliminar artículo?"))onSave(products.filter(p=>p.id!==id));};
  const dup=p=>{
    const copy={
      ...p,
      id:uid(),
      name:`${p.name} (copia)`,
      processes:p.processes?.map(pr=>({...pr,id:uid()})),
      materials:p.materials?.map(m=>({...m,id:uid()})),
    };
    onSave([...products,copy]);
  };
  return(
    <div style={{background:C.bg,minHeight:"100vh"}}>
      <Header title="CONFIGURACIÓN" onBack={onBack}/>
      <div style={{padding:14}}>
        <Btn onClick={()=>onGo("config-product",{ep:null})} style={{marginBottom:10}}>＋ Nuevo Artículo</Btn>
        <Btn v="blue" onClick={()=>onGo("users")} style={{marginBottom:10}}>👥 Gestionar Usuarios</Btn>
        <Btn v="green" onClick={()=>onGo("backup")} style={{marginBottom:14}}>💾 Copia de Seguridad</Btn>
        {products.length===0&&<div style={{textAlign:"center",padding:"40px 20px",color:C.muted}}><div style={{fontSize:52,marginBottom:12}}>📦</div><p style={{fontFamily:F.h,fontSize:18}}>Sin artículos configurados</p></div>}
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {products.map(p=>(
            <Card key={p.id}>
              <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:10}}>
                <div style={{flex:1}}>
                  <div style={{fontFamily:F.h,fontWeight:700,fontSize:19,color:C.text}}>{p.name}</div>
                  <div style={{fontSize:13,color:C.muted,marginTop:3}}>Unidad: <span style={{color:C.text}}>{p.unit||"—"}</span> · Rend. obj: <span style={{color:C.accent}}>{p.yieldTarget}%</span> · {p.processes?.length||0} procesos</div>
                </div>
                <div style={{display:"flex",gap:6,flexShrink:0}}>
                  <button onClick={()=>onGo("config-product",{ep:p})} title="Editar"
                    style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"8px 11px",cursor:"pointer",fontSize:16}}>✏️</button>
                  <button onClick={()=>dup(p)} title="Duplicar"
                    style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"8px 11px",cursor:"pointer",fontSize:16}}>📋</button>
                  <button onClick={()=>del(p.id)} title="Eliminar"
                    style={{background:"#fff",border:`1.5px solid ${C.red}`,color:C.red,borderRadius:8,padding:"8px 11px",cursor:"pointer",fontSize:16}}>🗑️</button>
                </div>
              </div>
              {p.processes?.length>0&&<div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${C.border}`,display:"flex",flexWrap:"wrap",gap:6}}>{p.processes.map(pr=><span key={pr.id} style={{background:"#fff",border:`1.5px solid ${pr.definesQty?C.green:C.border}`,borderRadius:8,padding:"4px 10px",fontSize:13,color:pr.definesQty?C.green:C.muted}}>{pr.definesQty?"★ ":""}{pr.deferred?"⏭ ":""}{pr.name} <span style={{color:C.accent,fontWeight:700}}>{pr.timeTarget}min</span></span>)}</div>}
              {p.materials?.length>0&&<div style={{marginTop:8,display:"flex",flexWrap:"wrap",gap:6}}>{p.materials.map(m=><span key={m.id} style={{background:"#fff",border:`1.5px solid ${C.border}`,borderRadius:8,padding:"4px 10px",fontSize:13,color:C.muted}}>{m.name}{m.supplier&&<span style={{color:C.muted}}> · {m.supplier}</span>} <span style={{color:C.text,fontWeight:600}}>{m.qtyPerUnit} {m.unit}</span></span>)}</div>}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function ConfigProductScreen({onBack,products,ep,onSave}){
  const [name,setName]   = useState(ep?.name||"");
  const [unit,setUnit]   = useState(ep?.unit||"Stick");
  const [yt,setYt]       = useState(ep?.yieldTarget?.toString()||"");
  const [procs,setProcs] = useState(ep?.processes||[]);
  const [pn,setPn]       = useState("");
  const [pt,setPt]       = useState("");
  const [mats,setMats]   = useState(ep?.materials||[]);
  const [mn,setMn]       = useState("");
  const [mu,setMu]       = useState("");
  const [mq,setMq]       = useState("");
  const [mp,setMp]       = useState("");
  const [msup,setMsup]   = useState("");
  const [editingProcId,setEditingProcId] = useState(null);
  const [editProcName,setEditProcName]   = useState("");
  const [editProcTime,setEditProcTime]   = useState("");
  const [editingMatId,setEditingMatId]   = useState(null);
  const [editMatName,setEditMatName]     = useState("");
  const [editMatSup,setEditMatSup]       = useState("");
  const [editMatQty,setEditMatQty]       = useState("");
  const [editMatUnit,setEditMatUnit]     = useState("");
  const [editMatPrice,setEditMatPrice]   = useState("");
  const addP=()=>{if(!pn.trim()||!pt)return;setProcs(prev=>[...prev,{id:uid(),name:pn.trim(),timeTarget:parseFloat(pt)}]);setPn("");setPt("");};
  const addM=()=>{if(!mn.trim()||!mq)return;setMats(prev=>[...prev,{id:uid(),name:mn.trim(),supplier:msup.trim(),unit:mu.trim()||"ud",qtyPerUnit:parseFloat(mq),pricePerUnit:parseFloat(mp)||0}]);setMn("");setMu("");setMq("");setMp("");setMsup("");};
  const save=()=>{
    if(!name.trim()||!unit.trim()||!yt)return alert("Completa nombre, unidad y rendimiento");
    const product={id:ep?.id||uid(),name:name.trim(),unit:unit.trim(),yieldTarget:parseFloat(yt),processes:procs,materials:mats};
    onSave(ep?products.map(p=>p.id===ep.id?product:p):[...products,product]);onBack();
  };
  const xBtn=fn=><button onClick={fn} style={{background:"none",border:"none",color:C.red,fontSize:22,cursor:"pointer",padding:"2px 8px"}}>✕</button>;
  const row=(children,key)=><div key={key} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 0",borderBottom:`1px solid ${C.border}`}}>{children}</div>;

  // Capture editing state for iOS Safari closure safety
  const _editingProcId=editingProcId, _editProcName=editProcName, _editProcTime=editProcTime;
  const _editingMatId=editingMatId, _editMatName=editMatName, _editMatSup=editMatSup;
  const _editMatQty=editMatQty, _editMatUnit=editMatUnit, _editMatPrice=editMatPrice;

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title={ep?"EDITAR ARTÍCULO":"NUEVO ARTÍCULO"} onBack={onBack}/>
      <div style={{padding:14}}>
        <Card style={{marginBottom:14}}>
          <Field label="Nombre del artículo" value={name} onChange={setName} placeholder="Ej: Calcetín modelo A"/>
          <Field label="Unidad de producción" value={unit} onChange={setUnit} placeholder="Ej: Sty, par, kg…"/>
          <Field label="Rendimiento objetivo (%)" value={yt} onChange={setYt} type="number" placeholder="85" min="0" step="0.1"/>
        </Card>
        <Card style={{marginBottom:14}}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.text,marginBottom:4}}>MATERIAS PRIMAS</div>
          <div style={{fontSize:13,color:C.muted,marginBottom:12}}>Cantidad necesaria por {unit||"unidad"}</div>
          {mats.length===0&&<p style={{color:C.muted,fontSize:14,marginBottom:12}}>Sin materias primas añadidas.</p>}
          {mats.map(m=>{
            const isEditingMat=_editingMatId===m.id;
            return(
              <div key={m.id} style={{padding:"10px 0",borderBottom:`1px solid ${C.border}`}}>
                {isEditingMat?(
                  <div>
                    <Field label="Nombre" value={_editMatName} onChange={setEditMatName} placeholder="Nombre materia prima"/>
                    <Field label="Proveedor" value={_editMatSup} onChange={setEditMatSup} placeholder="Proveedor"/>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                      <Field label={`Cant. / ${unit||"ud"}`} value={_editMatQty} onChange={setEditMatQty} type="number" placeholder="2.5" min="0" step="0.001"/>
                      <Field label="Unidad" value={_editMatUnit} onChange={setEditMatUnit} placeholder="metros, kg…"/>
                    </div>
                    <Field label="Precio por unidad (€)" value={_editMatPrice} onChange={setEditMatPrice} type="number" placeholder="0.45" min="0" step="0.001"/>
                    <div style={{display:"flex",gap:8}}>
                      <Btn v="primary" onClick={()=>{
                        if(!_editMatName.trim()||!_editMatQty)return;
                        setMats(prev=>prev.map(x=>x.id===m.id?{...x,name:_editMatName.trim(),supplier:_editMatSup.trim(),unit:_editMatUnit.trim()||"ud",qtyPerUnit:parseFloat(_editMatQty),pricePerUnit:parseFloat(_editMatPrice)||0}:x));
                        setEditingMatId(null);
                      }} style={{flex:1}}>✓ Guardar</Btn>
                      <Btn v="secondary" onClick={()=>setEditingMatId(null)} style={{flex:1}}>Cancelar</Btn>
                    </div>
                  </div>
                ):(
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:8}}>
                    <div style={{flex:1}}>
                      <span style={{fontFamily:F.h,fontWeight:600,fontSize:16,color:C.text}}>{m.name}</span>
                      <span style={{color:C.accent,fontSize:13,marginLeft:8}}>{m.qtyPerUnit} {m.unit}/{unit||"ud"}</span>
                      {m.pricePerUnit>0&&<span style={{color:C.muted,fontSize:13,marginLeft:8}}>{m.pricePerUnit}€/{m.unit}</span>}
                      {m.supplier&&<div style={{fontSize:12,color:C.muted,marginTop:2}}>{m.supplier}</div>}
                    </div>
                    <div style={{display:"flex",gap:6,flexShrink:0}}>
                      <button onClick={()=>{setEditingMatId(m.id);setEditMatName(m.name||"");setEditMatSup(m.supplier||"");setEditMatQty((m.qtyPerUnit||"").toString());setEditMatUnit(m.unit||"");setEditMatPrice((m.pricePerUnit||"").toString());}}
                        style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"5px 10px",cursor:"pointer",fontSize:15}}>✏️</button>
                      <button onClick={()=>setMats(prev=>prev.filter(x=>x.id!==m.id))}
                        style={{background:"none",border:"none",color:C.red,fontSize:20,cursor:"pointer",padding:"2px 6px"}}>✕</button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          <div style={{marginTop:14}}>
            <Field label="Nombre materia prima" value={mn} onChange={setMn} placeholder="Ej: Hilo de algodón"/>
            <Field label="Proveedor (opcional)" value={msup} onChange={setMsup} placeholder="Ej: Textiles García"/>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              <Field label={`Cant. / ${unit||"ud"}`} value={mq} onChange={setMq} type="number" placeholder="2.5" min="0" step="0.001"/>
              <Field label="Unidad" value={mu} onChange={setMu} placeholder="metros, kg…"/>
            </div>
            <Field label="Precio por unidad (€)" value={mp} onChange={setMp} type="number" placeholder="Ej: 0.45" min="0" step="0.001"/>
            <Btn v="ghost" onClick={addM}>＋ Añadir Materia Prima</Btn>
          </div>
        </Card>
        <Card style={{marginBottom:14}}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.text,marginBottom:4}}>PROCESOS</div>
          <div style={{fontSize:13,color:C.muted,marginBottom:12}}>Tiempo objetivo por {unit||"unidad"}</div>
          {procs.length===0&&<p style={{color:C.muted,fontSize:14,marginBottom:12}}>Sin procesos añadidos.</p>}
          {procs.map((p,i)=>{
            const isEditing = _editingProcId === p.id;
            const startEdit = () => {
              setEditProcName(p.name || "");
              setEditProcTime((p.timeTarget || "").toString());
              setEditingProcId(p.id);
            };
            const saveEdit = () => {
              if(!_editProcName.trim() || !_editProcTime) return;
              setProcs(prev => prev.map(x => x.id===p.id ? {...x, name:_editProcName.trim(), timeTarget:parseFloat(_editProcTime)} : x));
              setEditingProcId(null);
            };
            return (
              <div key={p.id} style={{padding:"12px 0",borderBottom:`1px solid ${C.border}`}}>
                {isEditing ? (
                  <div>
                    <Field label="Nombre" value={_editProcName} onChange={setEditProcName} placeholder="Nombre proceso"/>
                    <Field label={`Tiempo (min / ${unit||"ud"})`} value={_editProcTime} onChange={setEditProcTime} type="number" placeholder="1.5" min="0.01" step="0.01"/>
                    <div style={{display:"flex",gap:8}}>
                      <Btn v="primary" onClick={saveEdit} style={{flex:1}}>✓ Guardar</Btn>
                      <Btn v="secondary" onClick={()=>setEditingProcId(null)} style={{flex:1}}>Cancelar</Btn>
                    </div>
                  </div>
                ) : (
                  <div>
                    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
                      <div>
                        <span style={{fontFamily:F.h,fontWeight:600,fontSize:17,color:C.text}}>{i+1}. {p.name}</span>
                        <span style={{color:C.accent,fontSize:14,marginLeft:10}}>{p.timeTarget} min/{unit||"ud"}</span>
                      </div>
                      <div style={{display:"flex",gap:6}}>
                        <button onClick={startEdit} style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"5px 10px",cursor:"pointer",fontSize:15}}>✏️</button>
                        <button onClick={()=>setProcs(prev=>prev.filter(x=>x.id!==p.id))} style={{background:"none",border:"none",color:C.red,fontSize:20,cursor:"pointer",padding:"2px 6px"}}>✕</button>
                      </div>
                    </div>
                    <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:4}}>
                      <button onClick={()=>setProcs(prev=>prev.map(x=>({...x,definesQty:x.id===p.id})))}
                        style={{background:"#fff",border:`1.5px solid ${p.definesQty?C.green:C.border}`,color:p.definesQty?C.green:C.muted,borderRadius:20,padding:"5px 14px",fontSize:13,fontFamily:F.h,fontWeight:600,cursor:"pointer"}}>
                        {p.definesQty ? "✓ Define cantidad" : "◯ Define cantidad"}
                      </button>
                      <button onClick={()=>setProcs(prev=>prev.map(x=>x.id===p.id?{...x,deferred:!x.deferred}:x))}
                        style={{background:"#fff",border:`1.5px solid ${p.deferred?"#b45309":C.border}`,color:p.deferred?"#b45309":C.muted,borderRadius:20,padding:"5px 14px",fontSize:13,fontFamily:F.h,fontWeight:600,cursor:"pointer"}}>
                        {p.deferred ? "⏭ Diferido (día siguiente)" : "◯ Diferido (día siguiente)"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          <div style={{marginTop:14}}>
            <Field label="Nombre proceso" value={pn} onChange={setPn} placeholder="Ej: Tejido"/>
            <Field label={`Tiempo obj. (min / ${unit||"ud"})`} value={pt} onChange={setPt} type="number" placeholder="Ej: 1.5" min="0.01" step="0.01"/>
            <Btn v="ghost" onClick={addP}>＋ Añadir Proceso</Btn>
          </div>
        </Card>
        <Btn onClick={save}>💾 Guardar Artículo</Btn>
      </div>
    </div>
  );
}

// ── GESTIÓN DE USUARIOS ────────────────────────────────────────────────────────
function UsersScreen({onBack,users,onSave}){
  const [editUser,setEditUser]=useState(null); // null=list, {}=new, {id,...}=edit
  if(editUser!==null)return <UserFormScreen onBack={()=>setEditUser(null)} users={users} ep={editUser} onSave={onSave}/>;
  const del=id=>{
    if(users.filter(u=>u.role==="admin").length===1&&users.find(u=>u.id===id)?.role==="admin")return alert("No puedes eliminar el único administrador.");
    if(window.confirm("¿Eliminar usuario?"))onSave(users.filter(u=>u.id!==id));
  };
  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title="USUARIOS" onBack={onBack}/>
      <div style={{padding:14}}>
        <Btn onClick={()=>setEditUser({})} style={{marginBottom:14}}>＋ Nuevo Usuario</Btn>
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {users.map(u=>(
            <Card key={u.id}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:10}}>
                <div style={{flex:1}}>
                  <div style={{fontFamily:F.h,fontWeight:700,fontSize:18,color:C.text}}>{u.name}</div>
                  <div style={{fontSize:13,color:C.muted,marginTop:3}}>@{u.username} · <span style={{color:u.role==="admin"?C.accent:C.blue}}>{u.role==="admin"?"Administrador":"Operario"}</span></div>
                </div>
                <div style={{display:"flex",gap:8}}>
                  <button onClick={()=>setEditUser(u)} style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"8px 12px",cursor:"pointer",fontSize:16}}>✏️</button>
                  <button onClick={()=>del(u.id)} style={{background:"#fff",border:`1.5px solid ${C.red}`,color:C.red,borderRadius:8,padding:"8px 12px",cursor:"pointer",fontSize:16}}>🗑️</button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

function UserFormScreen({onBack,users,ep,onSave}){
  const isNew=!ep?.id;
  const [name,setName]=useState(ep?.name||"");
  const [username,setUsername]=useState(ep?.username||"");
  const [password,setPassword]=useState("");
  const [role,setRole]=useState(ep?.role||"operator");
  const [hoursPerDay,setHoursPerDay]=useState(ep?.hoursPerDay?.toString()||"8");
  const [costPerHour,setCostPerHour]=useState(ep?.costPerHour?.toString()||"");
  const [saved,setSaved]=useState(false);
  const save=()=>{
    if(!name.trim()||!username.trim())return alert("Nombre y usuario son obligatorios");
    if(isNew&&!password)return alert("La contraseña es obligatoria para usuarios nuevos");
    if(users.some(u=>u.username.toLowerCase()===username.toLowerCase()&&u.id!==ep?.id))return alert("Ese nombre de usuario ya existe");
    const user={id:ep?.id||uid(),name:name.trim(),username:username.trim().toLowerCase(),password:password||ep?.password,role,hoursPerDay:parseFloat(hoursPerDay)||8,costPerHour:parseFloat(costPerHour)||0};
    onSave(ep?.id?users.map(u=>u.id===ep.id?user:u):[...users,user]);
    setSaved(true);setTimeout(()=>{setSaved(false);onBack();},1200);
  };
  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:30}}>
      <Header title={isNew?"NUEVO USUARIO":"EDITAR USUARIO"} onBack={onBack}/>
      <div style={{padding:14}}>
        {saved&&<Toast msg="¡Guardado!"/>}
        <Card style={{marginBottom:14}}>
          <Field label="Nombre completo" value={name} onChange={setName} placeholder="Ej: Juan García"/>
          <Field label="Usuario (para login)" value={username} onChange={setUsername} placeholder="Ej: juan"/>
          <Field label={isNew?"Contraseña":"Nueva contraseña (vacío = sin cambiar)"} value={password} onChange={setPassword} type="password" placeholder="••••••"/>
          <Sel label="Rol" value={role} onChange={setRole} options={[{value:"admin",label:"Administrador — acceso total"},{value:"operator",label:"Operario — solo registro de tiempo"}]}/>
          {role==="operator"&&<Field label="Horas de trabajo / día" value={hoursPerDay} onChange={setHoursPerDay} type="number" placeholder="8" min="1" step="0.5"/>}
          {role==="operator"&&<Field label="Coste hora (€/h)" value={costPerHour} onChange={setCostPerHour} type="number" placeholder="Ej: 12.50" min="0" step="0.01"/>}
        </Card>
        <Btn onClick={save}>💾 Guardar Usuario</Btn>
      </div>
    </div>
  );
}


// ── BACKUP / RESTAURAR ─────────────────────────────────────────────────────────
function BackupScreen({onBack,products,orders,registers,users,onImport,onReset}){
  const [code,setCode]=useState("");
  const [msg,setMsg]=useState(null);
  const [showCode,setShowCode]=useState(false);
  const [confirmReset,setConfirmReset]=useState(false);

  const exportCode=store.exportAll();

  const doImport=()=>{
    const data=store.importAll(code);
    if(!data){setMsg({ok:false,text:"Código inválido. Comprueba que lo copiaste completo."});return;}
    onImport(data);
    setMsg({ok:true,text:"¡Datos restaurados correctamente!"});
    setTimeout(()=>onBack(),1500);
  };

  const doReset=()=>{
    onReset();
    setConfirmReset(false);
    setMsg({ok:true,text:"¡Datos de prueba eliminados. Artículos y usuarios conservados."});
    setTimeout(()=>onBack(),2000);
  };

  return(
    <div style={{background:C.bg,minHeight:"100vh",paddingBottom:40}}>
      <Header title="COPIA DE SEGURIDAD" onBack={onBack}/>
      <div style={{padding:14}}>
        {msg&&<Toast msg={msg.text} ok={msg.ok}/>}

        {/* Cloud status */}
        <Card style={{marginBottom:14,borderColor:store.isCloud()?C.green:C.border}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <div>
              <div style={{fontFamily:F.h,fontWeight:700,fontSize:16,color:store.isCloud()?C.green:C.muted,marginBottom:4}}>
                {store.isCloud()?"☁️ NUBE ACTIVA":"💾 SOLO LOCAL"}
              </div>
              <div style={{fontSize:13,color:C.muted}}>
                {store.isCloud()?"Los datos se sincronizan entre dispositivos":"Los datos solo se guardan en este dispositivo"}
              </div>
            </div>
            <button onClick={()=>{localStorage.removeItem("cloud_setup_done");SB.clearConfig();window.location.reload();}}
              style={{background:"#fff",border:`1.5px solid ${C.border}`,color:C.muted,borderRadius:8,padding:"8px 12px",cursor:"pointer",fontFamily:F.h,fontWeight:700,fontSize:13}}>
              {store.isCloud()?"Cambiar":"Configurar"}
            </button>
          </div>
          {store.isCloud()&&(
            <div>
              <div style={{fontSize:13,color:C.muted,marginBottom:10}}>
                ¿Tienes datos guardados localmente que no están en la nube? Súbelos con un clic:
              </div>
              <button onClick={async()=>{
                setMsg({ok:true,text:"Subiendo datos a la nube…"});
                const keys=["cp_products","cp_orders","cp_registers","cp_users"];
                let allOk=true;
                for(const k of keys){
                  const v=LS.get(k);
                  if(v!=null){const r=await SB.set(k,v);if(!r)allOk=false;}
                }
                setMsg({ok:allOk,text:allOk?"✅ Todos los datos sincronizados con la nube":"⚠️ Error al sincronizar. Comprueba la conexión."});
              }} style={{width:"100%",background:C.green,color:"#fff",border:"none",borderRadius:12,padding:"14px",fontFamily:F.h,fontWeight:700,fontSize:17,cursor:"pointer"}}>
                ☁️ Subir datos locales a la nube
              </button>
            </div>
          )}
        </Card>

        <Card style={{marginBottom:14,borderColor:`${C.green}88`}}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.green,marginBottom:8}}>📤 GUARDAR MIS DATOS</div>
          <div style={{fontSize:14,color:C.muted,marginBottom:12}}>
            Copia este código y guárdalo (notas, email…). Contiene todos tus artículos, órdenes y registros.
          </div>
          <div style={{display:"flex",gap:8,marginBottom:10}}>
            <button onClick={()=>setShowCode(s=>!s)} style={{flex:1,background:C.card2,border:`1px solid ${C.border}`,color:C.text,borderRadius:10,padding:"12px 14px",fontFamily:F.h,fontWeight:700,fontSize:16,cursor:"pointer"}}>
              {showCode?"🙈 Ocultar código":"👁️ Ver código"}
            </button>
          </div>
          {showCode&&(
            <div>
              <textarea readOnly value={exportCode} rows={5}
                style={{width:"100%",background:C.card2,border:`1px solid ${C.border}`,color:C.muted,borderRadius:10,padding:"12px 14px",fontFamily:"monospace",fontSize:11,resize:"none",boxSizing:"border-box"}}/>
              <div style={{fontSize:13,color:C.muted,marginTop:6}}>Selecciona todo el texto y cópialo</div>
            </div>
          )}
          <div style={{marginTop:10,padding:"10px 12px",background:C.card2,borderRadius:8,fontSize:13,color:C.muted}}>
            {products.length} artículos · {orders.length} órdenes · {registers.length} registros · {users.length} usuarios
          </div>
        </Card>

        <Card color={`${C.blue}88`} style={{marginBottom:14}}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.blue,marginBottom:8}}>📥 RESTAURAR DATOS</div>
          <div style={{fontSize:14,color:C.muted,marginBottom:12}}>
            Pega aquí un código de copia de seguridad guardado anteriormente.
          </div>
          <textarea value={code} onChange={e=>setCode(e.target.value)} placeholder="Pega aquí tu código de copia…" rows={5}
            style={{width:"100%",background:C.card2,border:`1px solid ${C.border}`,color:C.text,borderRadius:10,padding:"12px 14px",fontFamily:"monospace",fontSize:11,resize:"none",boxSizing:"border-box",marginBottom:10}}/>
          <Btn onClick={doImport} v="blue" disabled={!code.trim()}>📥 Restaurar</Btn>
        </Card>

        {/* Reset datos de prueba */}
        <Card color={`${C.red}66`}>
          <div style={{fontFamily:F.h,fontWeight:700,fontSize:17,color:C.red,marginBottom:8}}>🗑️ BORRAR DATOS DE PRUEBA</div>
          <div style={{fontSize:14,color:C.muted,marginBottom:14}}>
            Elimina todas las <strong style={{color:C.text}}>órdenes y registros de tiempo</strong>.<br/>
            Se conservan: artículos, procesos y usuarios.
          </div>
          {!confirmReset
            ?<Btn v="danger" onClick={()=>setConfirmReset(true)}>🗑️ Borrar órdenes y registros</Btn>
            :<div>
              <div style={{padding:"12px 14px",background:"#fff5f5",borderRadius:10,marginBottom:12,fontSize:14,color:C.red,fontFamily:F.h,fontWeight:600}}>
                ⚠️ Se borrarán {orders.length} órdenes y {registers.length} registros. Esta acción no se puede deshacer.
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <Btn v="secondary" onClick={()=>setConfirmReset(false)}>Cancelar</Btn>
                <Btn v="danger" onClick={doReset}>Confirmar borrado</Btn>
              </div>
            </div>
          }
        </Card>
      </div>
    </div>
  );
}


// ── EDITAR ORDEN CERRADA (solo del día) ───────────────────────────────────────
function EditOrderScreen({onBack, products, orders, registers, onSaveOrders, ep}){
  const prod = products.find(p => p.id === ep?.productId);
  const regs = registers.filter(r => r.orderId === ep?.id);

  const [qtyActual, setQtyActual] = useState(ep?.qtyActual?.toString() || "");
  const [matInputs, setMatInputs] = useState(() => {
    const init = {};
    ep?.materialResults?.forEach(m => { init[m.id] = m.actual?.toString() || ""; });
    return init;
  });
  const [saved, setSaved] = useState(false);

  const qtyNum = parseFloat(qtyActual) || 0;

  const matResults = (prod?.materials || []).map(m => {
    const expected = +(m.qtyPerUnit * qtyNum).toFixed(3);
    const actual   = parseFloat(matInputs[m.id]) || 0;
    const yieldPct = actual > 0 ? +((expected / actual) * 100).toFixed(1) : null;
    const waste    = actual > 0 ? +(actual - expected).toFixed(3) : null;
    return { ...m, expected, actual, yieldPct, waste };
  });

  const validYields = matResults.filter(m => m.yieldPct !== null);
  const globalYield = validYields.length > 0
    ? +(validYields.reduce((a, m) => a + m.yieldPct, 0) / validYields.length).toFixed(1)
    : ep?.yieldActual || 0;

  const save = () => {
    if (!qtyNum) return alert("Indica la cantidad producida");
    onSaveOrders(orders.map(o => o.id === ep.id ? {
      ...o,
      qtyActual: qtyNum,
      materialResults: matResults,
      yieldActual: globalYield,
    } : o));
    setSaved(true);
    setTimeout(() => { setSaved(false); onBack(); }, 1200);
  };

  return (
    <div style={{background:C.bg, minHeight:"100vh", paddingBottom:30}}>
      <Header title="EDITAR PRODUCCIÓN" onBack={onBack} sub={prod?.name || ""}/>
      <div style={{padding:14}}>
        {saved && <Toast msg="¡Cambios guardados!"/>}

        <Card style={{marginBottom:14}}>
          <div style={{padding:"8px 12px", background:C.card2, borderRadius:8, marginBottom:14, fontSize:13, color:C.muted}}>
            ✏️ Solo puedes editar órdenes cerradas del día de hoy
          </div>
          <Field
            label={`Cantidad total producida (${prod?.unit || "ud"})`}
            value={qtyActual} onChange={setQtyActual}
            type="number" placeholder={`Ej: ${ep?.qty || 100}`} min="0" step="1"/>
        </Card>

        {prod?.materials?.length > 0 && qtyNum > 0 && (
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h, fontWeight:700, fontSize:16, color:C.text, marginBottom:12}}>
              CONSUMO DE MATERIAS PRIMAS
            </div>
            {matResults.map(m => (
              <div key={m.id} style={{marginBottom:14, paddingBottom:14, borderBottom:`1px solid ${C.border}`}}>
                <div style={{display:"flex", justifyContent:"space-between", marginBottom:8}}>
                  <span style={{fontFamily:F.h, fontWeight:700, fontSize:16, color:C.text}}>{m.name}</span>
                  <span style={{fontSize:13, color:C.muted}}>Esperado: <span style={{color:C.blue}}>{m.expected} {m.unit}</span></span>
                </div>
                <Field
                  label={`Consumido (${m.unit})`}
                  value={matInputs[m.id] || ""}
                  onChange={v => setMatInputs(prev => ({...prev, [m.id]: v}))}
                  type="number" placeholder={`${m.expected}`} min="0" step="0.001"/>
                {m.yieldPct !== null && (
                  <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8}}>
                    <div style={{textAlign:"center", background:C.card2, borderRadius:8, padding:"7px 4px"}}>
                      <div style={{fontFamily:F.h, fontWeight:800, fontSize:18, color:m.yieldPct >= ep?.yieldTarget ? C.green : C.red}}>{m.yieldPct}%</div>
                      <div style={{fontSize:10, color:C.muted, textTransform:"uppercase"}}>Rendimiento</div>
                    </div>
                    <div style={{textAlign:"center", background:C.card2, borderRadius:8, padding:"7px 4px"}}>
                      <div style={{fontFamily:F.h, fontWeight:800, fontSize:18, color:C.text}}>{m.expected} {m.unit}</div>
                      <div style={{fontSize:10, color:C.muted, textTransform:"uppercase"}}>Esperado</div>
                    </div>
                    <div style={{textAlign:"center", background:C.card2, borderRadius:8, padding:"7px 4px"}}>
                      <div style={{fontFamily:F.h, fontWeight:800, fontSize:18, color:m.waste > 0 ? C.red : C.green}}>{m.waste > 0 ? "+" : ""}{m.waste} {m.unit}</div>
                      <div style={{fontSize:10, color:C.muted, textTransform:"uppercase"}}>{m.waste > 0 ? "Exceso" : "Ahorro"}</div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </Card>
        )}

        {/* Resumen procesos (solo lectura) */}
        {regs.length > 0 && (
          <Card style={{marginBottom:14}}>
            <div style={{fontFamily:F.h, fontWeight:700, fontSize:14, color:C.muted, marginBottom:10, textTransform:"uppercase", letterSpacing:0.5}}>
              Registros de tiempo (solo lectura)
            </div>
            {(()=>{
              const byProc = {};
              regs.forEach(r => {
                const pr = prod?.processes?.find(p => p.id === r.processId);
                if (!pr) return;
                if (!byProc[pr.id]) byProc[pr.id] = {name:pr.name, total:0};
                byProc[pr.id].total += r.minutes;
              });
              return Object.values(byProc).map(p => (
                <div key={p.name} style={{display:"flex", justifyContent:"space-between", padding:"7px 0", borderBottom:`1px solid ${C.border}`}}>
                  <span style={{fontSize:14, color:C.muted}}>{p.name}</span>
                  <span style={{fontFamily:F.h, fontWeight:700, fontSize:16, color:C.text}}>{p.total} min</span>
                </div>
              ));
            })()}
          </Card>
        )}

        <Btn onClick={save} disabled={!qtyNum}>💾 Guardar Cambios</Btn>
      </div>
    </div>
  );
}

// ── SAVE BAR ──────────────────────────────────────────────────────────────────
function SaveBar({status}){
  if(status==="ok") return null;
  const cfg={
    saving:{bg:C.greenBg,border:C.green,color:C.green,msg:"💾 Guardando…"},
    error:{bg:C.redBg,border:C.red,color:C.red,msg:"⚠️ Error al guardar — pulsa para copia manual"},
  };
  const s=cfg[status];
  if(!s) return null;
  return(
    <div style={{position:"fixed",bottom:0,left:0,right:0,background:s.bg,borderTop:`2px solid ${s.border}`,padding:"12px 16px",zIndex:100,fontFamily:F.h,fontWeight:700,fontSize:15,color:s.color,textAlign:"center"}}>
      {s.msg}
    </div>
  );
}

// ── ROOT ───────────────────────────────────────────────────────────────────────
export default function App(){
  const [session,setSession]=useState(null);
  const [view,setView]=useState("home");
  const [stack,setStack]=useState([]);
  const [ep,setEp]=useState(null);
  const [products,setProducts]=useState([]); const [orders,setOrders]=useState([]);
  const [registers,setRegisters]=useState([]);
  const [users,setUsers]=useState([]);
  const [ready,setReady]=useState(false);
  const [cloudSetupDone,setCloudSetupDone]=useState(true); // credenciales integradas
  const {isMobile,isTablet,isDesktop}=useBreakpoint(); // ← siempre arriba, antes de cualquier return

  useEffect(()=>{(async()=>{
    // 1. Carga inmediata desde localStorage — datos visibles al instante
    const pL=LS.get("cp_products")||[];
    const oL=LS.get("cp_orders")||[];
    const rL=LS.get("cp_registers")||[];
    let uL=LS.get("cp_users")||[];
    if(uL.length===0){uL=[{id:uid(),name:"Administrador",username:"admin",password:"1234",role:"admin"}];}
    setProducts(pL);setOrders(oL);setRegisters(rL);setUsers(uL);setReady(true);

    // 2. Sincroniza con Supabase en segundo plano (sin bloquear)
    try{
      const [p,o,r,u]=await Promise.all([
        SB.get("cp_products"),SB.get("cp_orders"),
        SB.get("cp_registers"),SB.get("cp_users")
      ]);
      if(p!=null){setProducts(p);LS.set("cp_products",p);}
      if(o!=null){setOrders(o);LS.set("cp_orders",o);}
      if(r!=null){setRegisters(r);LS.set("cp_registers",r);}
      if(u!=null&&u.length){setUsers(u);LS.set("cp_users",u);}
    }catch{}
  })();},[]);

  const [saveStatus,setSaveStatus]=useState("ok"); // "ok"|"saving"|"error"

  const persist=async(key,val,setter)=>{
    setter(val);
    setSaveStatus("saving");
    const ok=await store.set(key,val);
    // "ok" también si localStorage guardó (aunque window.storage falle)
    const lsOk=LS.get(key)!=null;
    const saved=ok||lsOk;
    setSaveStatus(saved?"ok":"error");
    if(saved)setTimeout(()=>setSaveStatus("ok"),1000);
  };
  const saveProducts =async v=>persist("cp_products",v,setProducts);
  const saveOrders   =async v=>persist("cp_orders",v,setOrders);
  const saveRegisters=async v=>persist("cp_registers",v,setRegisters);
  const saveUsers    =async v=>persist("cp_users",v,setUsers);

  const handleImport=(data)=>{
    if(data["cp_products"])setProducts(data["cp_products"]);
    if(data["cp_orders"])setOrders(data["cp_orders"]);
    if(data["cp_registers"])setRegisters(data["cp_registers"]);
    if(data["cp_users"])setUsers(data["cp_users"]);
    if(data["cp_products"])store.set("cp_products",data["cp_products"]);
    if(data["cp_orders"])store.set("cp_orders",data["cp_orders"]);
    if(data["cp_registers"])store.set("cp_registers",data["cp_registers"]);
    if(data["cp_users"])store.set("cp_users",data["cp_users"]);
  };

  const handleReset=()=>{
    setOrders([]);
    setRegisters([]);
    store.set("cp_orders",[]);
    store.set("cp_registers",[]);
    // Reset also in-memory cache
    DB["cp_orders"]=[];
    DB["cp_registers"]=[];
    LS.set("cp_orders",[]);
    LS.set("cp_registers",[]);
  };

  const go=(v,params={})=>{setStack(s=>[...s,view]);if(params.ep!==undefined)setEp(params.ep);setView(v);};
  const back=()=>{const s=[...stack];const prev=s.pop()||"home";setStack(s);setView(prev);};
  const logout=()=>{setSession(null);setView("home");setStack([]);};

  if(!ready)return <div style={{display:"flex",alignItems:"center",justifyContent:"center",minHeight:"100vh",background:"#f4f4f4",fontFamily:F.h,fontSize:22,color:C.muted}}>Cargando…</div>;

  // Cloud configurado automáticamente

  if(!session)return <LoginScreen users={users} onLogin={u=>setSession(u)}/>;

  const sh={products,orders,registers};

  const STYLES=`
    @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;800;900&family=Barlow:wght@400;500;600;700&display=swap');
    *{box-sizing:border-box;-webkit-tap-highlight-color:transparent;margin:0;padding:0;color-scheme:light !important;}
    html,body{background:#f4f4f4 !important;color:#1a1a1a !important;width:100%;height:100%;overflow-x:hidden;}
    #root,#app-root{background:#f4f4f4 !important;width:100%;min-height:100vh;}
    input,select,button,textarea{font-family:inherit;color-scheme:light !important;}
    input,select,textarea{background:#ffffff !important;color:#1a1a1a !important;}
    select option{background:#ffffff !important;color:#111827 !important;}
    ::-webkit-scrollbar{width:4px;}
    ::-webkit-scrollbar-track{background:#f4f4f4;}
    ::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:4px;}
  `;

  const adminNav=[
    {id:"home",    icon:"🏠", label:"Inicio"},
    {id:"plan",    icon:"📋", label:"Plan"},
    {id:"registro",icon:"⏱️", label:"Registrar"},
    {id:"cerrar",  icon:"📦", label:"Cerrar"},
    {id:"resultados",icon:"🏁",label:"Resultados"},
    {id:"stats",   icon:"📊", label:"Stats"},
    {id:"config",  icon:"⚙️", label:"Config"},
  ];

  // Top navigation bar — works at any width
  const TopNav=()=>(
    <div style={{background:C.card,borderBottom:`2px solid ${C.border}`,position:"sticky",top:0,zIndex:20,boxShadow:"0 2px 8px rgba(0,0,0,0.07)",width:"100%"}}>
      {/* Brand row */}
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 16px 8px",borderBottom:`1px solid ${C.border}`}}>
        <WikukBrand dark={true} size="small"/>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:12,color:store.isCloud()?C.green:C.muted,fontFamily:F.b}} title={store.isCloud()?"Sincronizando en la nube":"Solo local"}>
            {store.isCloud()?"☁️ Nube":"💾 Local"}
          </span>
          <span style={{fontFamily:F.b,fontSize:13,color:C.muted}}>{session?.name}</span>
          <button onClick={logout} style={{padding:"6px 14px",borderRadius:8,border:`1.5px solid ${C.border}`,background:"#fff",color:C.muted,fontFamily:F.h,fontWeight:700,fontSize:14,cursor:"pointer"}}>Salir</button>
        </div>
      </div>
      {/* Nav tabs — scrollable */}
      <div style={{display:"flex",overflowX:"auto",padding:"0 8px",WebkitOverflowScrolling:"touch",scrollbarWidth:"none"}}>
        {adminNav.map(item=>(
          <button key={item.id} onClick={()=>go(item.id)}
            style={{flexShrink:0,display:"flex",alignItems:"center",gap:6,padding:"10px 14px",border:"none",borderBottom:`3px solid ${view===item.id?C.accent:"transparent"}`,background:"transparent",color:view===item.id?C.text:C.muted,fontFamily:F.h,fontWeight:700,fontSize:15,cursor:"pointer",whiteSpace:"nowrap"}}>
            <span style={{fontSize:18}}>{item.icon}</span>{item.label}
          </button>
        ))}
      </div>
    </div>
  );

  const renderScreen=()=>{
    if(view==="home")           return <AdminHome    onGo={go} onLogout={logout} session={session} {...sh}/>;
    if(view==="plan")           return <PlanScreen   onBack={back} onGo={go} {...sh} onSaveOrders={saveOrders}/>;
    if(view==="plan-new")       return <PlanNewScreen onBack={back} {...sh} users={users} onSaveOrders={saveOrders}/>;
    if(view==="registro")       return <RegistroScreen onBack={back} session={session} {...sh} onSaveRegisters={saveRegisters}/>;
    if(view==="cerrar")         return <CerrarScreen  onBack={back} {...sh} onSaveOrders={saveOrders}/>;
    if(view==="resultados")     return <ResultadosScreen onBack={back} {...sh} users={users}/>;
    if(view==="stats")          return <StatsScreen   onBack={back} {...sh} users={users}/>;
    if(view==="config")         return <ConfigScreen  onBack={back} onGo={go} products={products} onSave={saveProducts}/>;
    if(view==="config-product") return <ConfigProductScreen onBack={back} products={products} ep={ep} onSave={saveProducts}/>;
    if(view==="users")          return <UsersScreen   onBack={back} users={users} onSave={saveUsers}/>;
    if(view==="edit-order")     return <EditOrderScreen onBack={back} products={products} orders={orders} registers={registers} onSaveOrders={saveOrders} ep={ep}/>;
    if(view==="backup")         return <BackupScreen  onBack={back} products={products} orders={orders} registers={registers} users={users} onImport={handleImport} onReset={handleReset}/>;
    return null;
  };

  // OPERARIO
  if(session.role==="operator"){
    return(
      <div id="app-root" style={{fontFamily:F.b,width:"100vw",minHeight:"100vh",background:"#f0f2f5",overflowX:"hidden"}}>
        <style>{STYLES}</style>
        <div style={{width:"100%"}}>
          {view==="registro"
            ?<RegistroScreen onBack={()=>setView("home")} session={session} {...sh} onSaveRegisters={saveRegisters}/>
            :<OperatorHome onGo={v=>setView(v)} onLogout={logout} session={session} orders={orders} registers={registers}/>
          }
        </div>
      </div>
    );
  }

  // ADMIN
  return(
    <div id="app-root" style={{fontFamily:F.b,width:"100vw",minHeight:"100vh",background:"#f0f2f5",overflowX:"hidden"}}>
      <style>{STYLES}</style>
      <TopNav/>
      {saveStatus==="error"&&(
        <div style={{background:C.redBg,borderBottom:`2px solid ${C.red}`,padding:"10px 16px",fontFamily:F.h,fontWeight:700,fontSize:13,color:C.red,textAlign:"center",cursor:"pointer"}} onClick={()=>go("backup")}>
          ⚠️ Error al guardar — pulsa aquí para hacer copia manual
        </div>
      )}
      <SaveBar status={saveStatus}/>
      <div style={{width:"100%"}}>
        {renderScreen()}
      </div>
    </div>
  );
}
